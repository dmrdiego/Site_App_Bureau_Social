# Guia de Uso e Manutenção - Site Bureau Social

## 1. Visão Geral do Site

O site do **Instituto Português de Negócios Sociais – Bureau Social** foi desenvolvido utilizando tecnologias modernas e está pronto para ser utilizado como ferramenta principal de comunicação institucional.

### Tecnologias Utilizadas

- **React 18:** Biblioteca JavaScript moderna para construção de interfaces
- **Vite:** Ferramenta de build rápida e eficiente
- **Tailwind CSS:** Framework CSS para estilização responsiva
- **shadcn/ui:** Componentes de interface pré-construídos
- **Lucide Icons:** Biblioteca de ícones moderna
- **React Router:** Navegação entre páginas

### Estrutura do Projeto

```
bureau-social-website/
├── public/
│   ├── documentos/          # Documentos para download
│   └── favicon.ico
├── src/
│   ├── assets/              # Imagens e recursos
│   │   ├── LogotipoVerde.png
│   │   └── LogoGotasJuntas_Preto.png
│   ├── components/          # Componentes React
│   │   └── ui/              # Componentes de interface
│   ├── App.jsx              # Componente principal
│   ├── App.css              # Estilos personalizados
│   └── main.jsx             # Ponto de entrada
├── index.html               # HTML principal
└── package.json             # Dependências do projeto
```

## 2. Como Atualizar o Conteúdo

### 2.1 Atualizar Textos das Páginas

Todos os textos das páginas estão no arquivo `src/App.jsx`. Para editar:

1. Abra o arquivo `/home/ubuntu/bureau-social-website/src/App.jsx`
2. Localize a função da página que deseja editar (ex: `HomePage`, `QuemSomosPage`)
3. Edite o texto diretamente no código JSX
4. Salve o arquivo

**Exemplo - Alterar texto da Hero Section:**

```jsx
// Localize esta seção em HomePage()
<h1 className="text-4xl md:text-6xl font-bold mb-6 animate-fade-in">
  Impacto Positivo e Negócios Rentáveis
</h1>
```

### 2.2 Adicionar Notícias

Para adicionar notícias, você precisará editar a página `NoticiasPage` no arquivo `App.jsx`:

1. Localize a função `NoticiasPage()`
2. Substitua o placeholder por uma lista de notícias
3. Adicione cards com título, data, resumo e link

**Exemplo de estrutura para notícias:**

```jsx
const noticias = [
  {
    titulo: 'Lançamento do Bureau Social',
    data: '11 de Outubro de 2025',
    resumo: 'Instituto é oficialmente constituído...',
    imagem: '/caminho/para/imagem.jpg'
  },
  // Mais notícias...
]
```

### 2.3 Adicionar Novos Documentos

Para adicionar documentos à Central de Documentos:

1. Coloque o arquivo na pasta `/home/ubuntu/bureau-social-website/public/documentos/`
2. Edite o array `documents` na função `DocumentosPage()` em `App.jsx`
3. Adicione uma nova entrada com nome e caminho do arquivo

**Exemplo:**

```jsx
{
  category: 'Relatórios',
  files: [
    { 
      name: 'Relatório Anual 2025', 
      file: 'relatorio-anual-2025.pdf' 
    }
  ]
}
```

### 2.4 Atualizar Informações de Contato

Localize as seguintes seções para atualizar informações de contato:

**No Footer (componente `Footer()`):**
```jsx
<span className="opacity-90">Rua do Salvador, 20, 1.º A<br />Lisboa, Portugal</span>
<span className="opacity-90">+351 XXX XXX XXX</span>
<span className="opacity-90">info@bureausocial.pt</span>
```

**Na Página de Contato (função `ContatoPage()`):**
Mesmas informações aparecem em cards separados.

### 2.5 Adicionar Imagens

Para adicionar novas imagens:

1. Coloque a imagem na pasta `src/assets/`
2. Importe no início do arquivo `App.jsx`:
   ```jsx
   import minhaImagem from './assets/minha-imagem.jpg'
   ```
3. Use a imagem no código:
   ```jsx
   <img src={minhaImagem} alt="Descrição" />
   ```

## 3. Como Fazer Deploy de Atualizações

### 3.1 Testar Localmente

Antes de fazer deploy, sempre teste localmente:

```bash
cd /home/ubuntu/bureau-social-website
pnpm run dev
```

Acesse `http://localhost:5173` no navegador para verificar as alterações.

### 3.2 Build de Produção

Para criar a versão de produção:

```bash
cd /home/ubuntu/bureau-social-website
pnpm run build
```

Isso criará uma pasta `dist/` com os arquivos otimizados.

### 3.3 Deploy

O site já foi configurado para deploy. Para atualizar:

1. Faça as alterações necessárias
2. Teste localmente
3. Execute o build de produção
4. O sistema de deploy detectará automaticamente as mudanças

## 4. Funcionalidades Implementadas

### 4.1 Navegação

- **Menu Principal:** Fixo no topo com 8 seções
- **Menu Mobile:** Menu hamburger responsivo para dispositivos móveis
- **Indicação Visual:** Página atual destacada no menu
- **Links Internos:** Navegação suave entre páginas

### 4.2 Páginas

**Página Inicial:**
- Hero section com chamadas para ação
- Apresentação resumida do Instituto
- Cards das áreas de atuação
- Seção de call-to-action para associação

**Quem Somos:**
- Missão, Visão e Valores
- Princípios ESG detalhados
- Alinhamento com ODS da ONU
- Cards de valores organizacionais

**Áreas de Atuação:**
- Cinco áreas estratégicas
- Descrição detalhada de cada área
- Ícones representativos
- Cards expansivos com hover effects

**Associe-se:**
- Oito categorias de associados
- Descrição de cada categoria
- Benefícios de ser associado
- Call-to-action para contato

**Parcerias:**
- Tipos de parceiros
- Exemplos de organizações
- Oportunidades de colaboração
- Formulário de interesse

**Documentos:**
- Central de documentos organizada por categorias
- Botões de download direto
- Ícones e descrições claras
- Documentos institucionais disponíveis

**Notícias:**
- Preparada para publicação de notícias
- Atualmente com placeholder

**Contato:**
- Informações de contato completas
- Formulário de contato (a ser integrado)
- Links para redes sociais
- Cards informativos

### 4.3 Componentes Reutilizáveis

O site utiliza componentes do shadcn/ui que podem ser reutilizados:

- **Button:** Botões com diferentes variantes
- **Card:** Cards para conteúdo estruturado
- **CardHeader, CardTitle, CardDescription, CardContent:** Partes do card

**Exemplo de uso:**

```jsx
<Card>
  <CardHeader>
    <CardTitle>Título</CardTitle>
    <CardDescription>Descrição</CardDescription>
  </CardHeader>
  <CardContent>
    Conteúdo do card
  </CardContent>
</Card>
```

### 4.4 Responsividade

O site é totalmente responsivo com breakpoints:

- **Mobile:** < 768px
- **Tablet:** 768px - 1024px
- **Desktop:** > 1024px

Classes Tailwind para responsividade:
- `md:` - Tablet e acima
- `lg:` - Desktop e acima

**Exemplo:**
```jsx
<h1 className="text-4xl md:text-6xl">
  // 4xl em mobile, 6xl em tablet+
</h1>
```

## 5. Personalizações de Design

### 5.1 Cores

As cores estão definidas em `src/App.css` usando variáveis CSS:

```css
:root {
  --primary: oklch(0.60 0.12 130);      /* Verde Bureau Social */
  --secondary: oklch(0.38 0.08 130);    /* Verde Escuro */
  --accent: oklch(0.80 0.10 130);       /* Verde Claro */
}
```

Para alterar cores, edite estas variáveis no arquivo `App.css`.

### 5.2 Classes Personalizadas

Classes CSS personalizadas disponíveis:

- `.hero-gradient` - Gradiente verde para hero sections
- `.section-padding` - Padding padrão para seções (py-16 md:py-24)
- `.container-custom` - Container com padding responsivo
- `.card-hover` - Efeito hover para cards
- `.btn-primary` - Estilo de botão primário
- `.btn-secondary` - Estilo de botão secundário

### 5.3 Ícones

O site usa Lucide Icons. Para adicionar novos ícones:

1. Importe no início do arquivo:
   ```jsx
   import { NomeDoIcone } from 'lucide-react'
   ```
2. Use no código:
   ```jsx
   <NomeDoIcone size={24} className="text-primary" />
   ```

Catálogo completo: https://lucide.dev/icons/

## 6. Próximos Passos Recomendados

### 6.1 Integração de Formulários

Para tornar o formulário de contato funcional:

**Opção 1 - EmailJS (Gratuito):**
```bash
pnpm add @emailjs/browser
```

**Opção 2 - Formspree (Gratuito até 50 envios/mês):**
Apenas adicione o endpoint no action do formulário.

**Opção 3 - Backend Próprio:**
Criar API com Node.js/Express para processar formulários.

### 6.2 Sistema de Newsletter

Recomendações de serviços:

- **Mailchimp:** Gratuito até 500 contatos
- **Sendinblue:** Gratuito até 300 emails/dia
- **ConvertKit:** Focado em criadores de conteúdo

### 6.3 Google Analytics

Para adicionar tracking:

1. Criar conta no Google Analytics
2. Obter ID de tracking (G-XXXXXXXXXX)
3. Adicionar script no `index.html`:

```html
<script async src="https://www.googletagmanager.com/gtag/js?id=G-XXXXXXXXXX"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());
  gtag('config', 'G-XXXXXXXXXX');
</script>
```

### 6.4 SEO

Para melhorar SEO:

1. **Meta Tags:** Já implementadas no `index.html`
2. **Sitemap:** Criar arquivo `sitemap.xml` na pasta `public/`
3. **robots.txt:** Criar arquivo `robots.txt` na pasta `public/`
4. **Google Search Console:** Submeter site e sitemap

### 6.5 Redes Sociais

Links de redes sociais estão no Footer e página de Contato. Para atualizar:

1. Localize os links no código (procure por `href="#"`)
2. Substitua `#` pelos URLs reais das redes sociais
3. Exemplo: `href="https://www.facebook.com/bureausocial"`

## 7. Manutenção e Suporte

### 7.1 Atualizações de Dependências

Para manter o projeto atualizado:

```bash
cd /home/ubuntu/bureau-social-website
pnpm update
```

### 7.2 Backup

Recomenda-se fazer backup regular de:
- Código fonte (pasta completa do projeto)
- Documentos na pasta `public/documentos/`
- Imagens na pasta `src/assets/`

### 7.3 Monitoramento

Monitore regularmente:
- **Performance:** Velocidade de carregamento (Google PageSpeed Insights)
- **Erros:** Console do navegador para erros JavaScript
- **Links Quebrados:** Verificar periodicamente links internos e externos
- **Formulários:** Testar envio de formulários quando integrados

### 7.4 Segurança

Boas práticas de segurança:
- Manter dependências atualizadas
- Não expor informações sensíveis no código
- Usar HTTPS no domínio de produção
- Validar inputs de formulários

## 8. Recursos Adicionais

### 8.1 Documentação

- **React:** https://react.dev/
- **Vite:** https://vitejs.dev/
- **Tailwind CSS:** https://tailwindcss.com/
- **shadcn/ui:** https://ui.shadcn.com/
- **Lucide Icons:** https://lucide.dev/

### 8.2 Suporte Técnico

Para questões técnicas:
- Documentação oficial das tecnologias
- Stack Overflow para problemas específicos
- GitHub Issues dos projetos open-source utilizados

### 8.3 Melhorias Futuras

Considere implementar:
- Sistema de gestão de conteúdo (CMS) para facilitar atualizações
- Área de associado com login
- Sistema de doações online
- Blog com sistema de comentários
- Galeria de fotos e vídeos
- Calendário de eventos interativo
- Multilíngue (português/inglês)

## 9. Checklist de Lançamento

Antes do lançamento oficial, verifique:

- [ ] Todos os textos revisados e sem erros
- [ ] Informações de contato atualizadas
- [ ] Links de redes sociais funcionais
- [ ] Documentos disponíveis para download
- [ ] Imagens otimizadas e com alt text
- [ ] Formulário de contato funcional
- [ ] Google Analytics configurado
- [ ] Sitemap e robots.txt criados
- [ ] Teste em diferentes navegadores (Chrome, Firefox, Safari, Edge)
- [ ] Teste em diferentes dispositivos (desktop, tablet, mobile)
- [ ] Performance otimizada (PageSpeed > 80)
- [ ] Favicon personalizado
- [ ] Meta tags para redes sociais (Open Graph)
- [ ] Certificado SSL/HTTPS ativo
- [ ] Domínio configurado corretamente

## 10. Contatos para Suporte

Para questões sobre o site desenvolvido:
- Documentação técnica: Este guia
- Código fonte: `/home/ubuntu/bureau-social-website/`
- Análise e recomendações: `/home/ubuntu/analise_e_recomendacoes.md`

---

**Última atualização:** 11 de Outubro de 2025

