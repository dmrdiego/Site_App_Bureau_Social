# Análise dos Documentos - Instituto Português de Negócios Sociais – Bureau Social

## 1. Informações Institucionais Coletadas

### 1.1 Identidade da Organização
- **Nome**: Instituto Português de Negócios Sociais – Bureau Social
- **Natureza Jurídica**: Associação sem fins lucrativos / IPSS (Instituição Particular de Solidariedade Social)
- **Sede**: Rua do Salvador, n.º 20, 1.º A, Lisboa, Portugal
- **Tagline**: "Impacto positivo e negócios rentáveis" (conforme logotipo)
- **Duração**: Ilimitada

### 1.2 Missão, Visão e Objetivos

**Missão**: Promover soluções inovadoras de economia social que contribuam para a realização dos direitos sociais em Portugal, dando expressão organizada ao dever moral de justiça e solidariedade.

**Visão**: Tornar-se referência nacional na construção de soluções sociais sustentáveis e inclusivas, inspirando outras organizações e mobilizando parcerias público-privadas.

**Objetivos Principais**:
- Desenvolver programas de impacto social em habitação, inclusão socioeconómica, sustentabilidade e cidadania
- Articular intervenção com políticas públicas
- Alinhar ações com ODS da ONU (especialmente ODS 1, 8, 11 e 16)
- Implementar princípios ESG (Ambiental, Social e Governança)

### 1.3 Áreas de Atuação

1. **Habitação Social e Reutilização de Imóveis Devolutos**
   - Identificação e reabilitação de habitações degradadas ou desocupadas
   - Coordenação com IHRU e câmaras municipais
   - Programas de arrendamento acessível

2. **Inovação e Empreendedorismo Social**
   - Criação e escalonamento de negócios sociais inovadores
   - Apoio a incubadoras sociais
   - Formações e bootcamps de empreendedorismo social

3. **Sustentabilidade Ambiental e Princípios ESG**
   - Práticas sustentáveis e economia circular
   - Eficiência energética em reabilitações
   - Formação em competências verdes

4. **Economia Circular, Inclusão Produtiva e Emprego Verde**
   - Inclusão de grupos vulneráveis no mercado de trabalho
   - Projetos de reciclagem e compostagem comunitária
   - Mobilidade sustentável

5. **Educação para a Cidadania e Envolvimento Comunitário**
   - Literacia cívica e participação democrática
   - Ações educativas não formais
   - Parcerias com escolas e associações culturais

### 1.4 Categorias de Associados

- **Fundadores**: Participaram na assembleia de constituição
- **Efetivos**: Contribuintes sem infrações, convidados pela Direção
- **Contribuintes**: Pagam quotas associativas
- **Voluntários**: Integram equipas de voluntariado (isentos de quotas)
- **Profissionais**: Prestadores ou especialistas em projetos (isentos de quotas)
- **Beneméritos**: Prestaram serviços relevantes ou doações significativas (isentos de quotas)
- **Patrocinadores**: Pessoas coletivas que apoiam financeiramente
- **Institucionais**: Pessoas coletivas do primeiro, segundo ou terceiro setor

### 1.5 Estrutura Organizacional

**Órgãos Sociais**:
- **Assembleia Geral**: Órgão máximo deliberativo
- **Direção**: Órgão executivo (presidente, vice-presidente, secretário, tesoureiro)
- **Conselho Fiscal**: Órgão de fiscalização independente

**Órgãos Adicionais**:
- **Secretaria Executiva**: Gestão cotidiana
- **Conselho de Profissionais**: Corpo consultivo

### 1.6 Parcerias Institucionais

- **Autarquias Locais**: Câmaras Municipais (Lisboa, Porto, etc.)
- **Governo Central**: IHRU, Ministérios (Trabalho, Solidariedade, Ambiente, Saúde, Habitação)
- **Organismos Europeus**: PRR, Fundos Estruturais, EEA Grants, FAMI

### 1.7 Linhas de Financiamento

- Fundos Europeus Estruturais e de Investimento (Portugal 2030, PRR)
- Fundo Social Europeu (Portugal Inovação Social)
- FAMI (Fundo Asilo, Migração e Integração)
- Títulos de Impacto Social
- Fundos Nacionais e Municipais
- Investimento de Impacto e Filantropia

## 2. Elementos Visuais

### 2.1 Logotipos Disponíveis

1. **LogotipoVerde.png**: Logotipo principal em verde com três círculos interligados e triângulo central, texto "bureau social" e tagline "Impacto positivo e negócios rentáveis"

2. **LogoGotasJuntas_Preto.png**: Versão em preto do símbolo (três círculos com triângulo central)

### 2.2 Identidade Visual

- **Cores principais**: Verde (sustentabilidade, crescimento), Preto (profissionalismo)
- **Símbolo**: Três círculos interligados com triângulo central (representando interconexão, colaboração, impacto triplo)
- **Tipografia**: Moderna, clean, minúscula para "bureau social"

## 3. Documentos Disponíveis para Central de Documentos

1. **Estatuto do Instituto Português de Negócios Sociais** (8 páginas)
2. **Escopo Institucional** (5 páginas)
3. **Documentos para Constituição da Associação** (7 páginas)

## 4. Pontos de Melhoria Identificados

### 4.1 Presença Digital
- Necessidade de website institucional profissional
- Ausência de plataforma para apresentação a potenciais associados
- Falta de central de documentos online acessível

### 4.2 Comunicação Institucional
- Necessidade de materiais de apresentação claros e atrativos
- Informações sobre como se associar
- Transparência sobre projetos e impacto

### 4.3 Estrutura de Informação
- Organização clara das categorias de associados e benefícios
- Apresentação dos órgãos sociais e equipe
- Informações sobre parcerias e financiadores

## 5. Referências e Casos de Sucesso

### Portugal
- Portugal Inovação Social
- IES – Instituto de Empreendedorismo Social
- Santa Casa da Misericórdia de Lisboa
- Fundação EDP

### Europa
- Ashoka
- Impact Hubs
- Yunus Social Business
- Big Society Capital (Reino Unido)

## 6. Legislação de Referência

- Estatuto das IPSS (Decreto-Lei n.º 119/83, alterado)
- Lei 30/2013 (Economia Social)
- Lei n.º 36/2021 (Utilidade Pública)
- Estratégia Nacional de Educação para a Cidadania (ENEC)
- PRR (Plano de Recuperação e Resiliência)

