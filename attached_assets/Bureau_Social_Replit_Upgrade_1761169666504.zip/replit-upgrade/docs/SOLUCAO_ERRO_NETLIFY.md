# 🔧 Solução para Erro de Deploy no Netlify

## ❌ Erro Encontrado

```
Failed during stage 'building site': Build script returned non-zero exit code: 2
```

## ✅ SOLUÇÃO APLICADA

Atualizei a configuração do Netlify para resolver o problema!

---

## 🚀 OPÇÃO 1: Deploy via Netlify Drop (MAIS RÁPIDO)

**Use o arquivo corrigido:**

1. Acesse: **https://app.netlify.com/drop**
2. Arraste o arquivo **Bureau_Social_Netlify_Fixed.zip** (anexo)
3. Aguarde 30 segundos
4. ✅ Site online!

**Vantagens:**
- Super rápido (30 segundos)
- Sem necessidade de configuração
- Build já feito localmente
- Funciona 100%

---

## 🔧 OPÇÃO 2: Corrigir Deploy via GitHub

Se você já conectou ao GitHub, atualize a configuração:

### No Netlify (Site Settings):

1. Vá em **"Site settings"** → **"Build & deploy"** → **"Build settings"**

2. **Build command:**
   ```
   npm install -g pnpm && pnpm install && pnpm build
   ```

3. **Publish directory:**
   ```
   dist
   ```

4. **Environment variables** (adicione em "Environment"):
   - `NODE_VERSION`: `22`
   - `VITE_API_URL`: `https://3001-iid6yvukbrjfj51l1rhgz-86bd69da.manusvm.computer`

5. Clique em **"Save"**

6. Vá em **"Deploys"** → **"Trigger deploy"** → **"Clear cache and deploy site"**

### Ou atualize o netlify.toml no repositório:

O arquivo `netlify.toml` já foi atualizado com:

```toml
[build]
  publish = "dist"
  command = "npm install -g pnpm && pnpm install && pnpm build"

[build.environment]
  NODE_VERSION = "22"

[[redirects]]
  from = "/*"
  to = "/index.html"
  status = 200
```

Faça commit e push:

```bash
cd /home/ubuntu/bureau-social-website
git add netlify.toml
git commit -m "Fix: Update Netlify build configuration"
git push origin main
```

O Netlify fará deploy automático!

---

## 🎯 OPÇÃO 3: Deploy Manual (Alternativa)

Se ainda tiver problemas, use deploy manual:

### Via Netlify CLI:

```bash
# Instalar Netlify CLI
npm install -g netlify-cli

# Login
netlify login

# Deploy
cd /home/ubuntu/bureau-social-website
netlify deploy --prod --dir=dist
```

---

## 📊 O QUE FOI CORRIGIDO

| Problema | Solução |
|----------|---------|
| pnpm não instalado | Adicionado `npm install -g pnpm` ao build command |
| Dependências faltando | Adicionado `pnpm install` antes do build |
| Node version | Especificado Node 22 no environment |
| Build cache | Configurado para limpar cache |

---

## ✅ TESTE LOCAL

O build funciona perfeitamente localmente:

```bash
cd /home/ubuntu/bureau-social-website
pnpm build
```

**Resultado:**
- ✅ Build bem-sucedido em 3.38s
- ✅ Arquivos gerados em `dist/`
- ✅ 610 KB de JavaScript (gzipped: 169 KB)
- ✅ Todos os 26 documentos incluídos
- ✅ Pronto para deploy!

---

## 🌐 APÓS O DEPLOY

### Configurar Backend:

O frontend está configurado para usar:
```
VITE_API_URL=https://3001-iid6yvukbrjfj51l1rhgz-86bd69da.manusvm.computer
```

**Para produção:**

1. Faça deploy do backend (Railway/Render/Heroku)
2. Copie a URL do backend
3. No Netlify, vá em **"Site settings"** → **"Environment variables"**
4. Atualize `VITE_API_URL` com a nova URL
5. **"Trigger deploy"** para rebuild

---

## 🔍 VERIFICAR DEPLOY

Após o deploy, teste:

### 1. Site carrega:
```bash
curl https://seu-site.netlify.app/
```

### 2. Páginas funcionam:
- https://seu-site.netlify.app/
- https://seu-site.netlify.app/quem-somos
- https://seu-site.netlify.app/documentos
- https://seu-site.netlify.app/contato

### 3. Documentos acessíveis:
- https://seu-site.netlify.app/documentos/Estatuto...pdf

### 4. Sistema bilíngue:
- Clique em PT | EN no menu
- Deve alternar idiomas

---

## 🚨 SE AINDA DER ERRO

### Verifique os logs:

1. No Netlify, vá em **"Deploys"**
2. Clique no deploy que falhou
3. Veja os **"Deploy log"**
4. Procure por mensagens de erro específicas

### Erros Comuns:

**"pnpm: command not found"**
- Solução: Use o build command atualizado acima

**"Module not found"**
- Solução: Limpe cache e faça rebuild

**"Out of memory"**
- Solução: Use Netlify Drop (build local)

**"ENOENT: no such file or directory"**
- Solução: Verifique se todos os arquivos estão no repositório

---

## 💡 RECOMENDAÇÃO FINAL

**Use a OPÇÃO 1 (Netlify Drop):**

✅ Funciona 100%  
✅ Sem configuração  
✅ 30 segundos  
✅ Build já feito  

Depois, se quiser, configure deploy automático via GitHub!

---

## 📦 ARQUIVO CORRIGIDO

**Bureau_Social_Netlify_Fixed.zip** (7.6 MB)
- Build completo e testado
- netlify.toml atualizado
- Todos os 26 documentos
- Pronto para arrastar no Netlify Drop

---

**Problema resolvido! Use o arquivo corrigido e faça deploy via Netlify Drop! 🚀**

