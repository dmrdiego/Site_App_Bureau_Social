# Análise de Documentos Existentes - Bureau Social

## 1. Documentos Já Disponíveis

### 1.1 Estatuto do Instituto Português de Negócios Sociais

**Arquivo:** EstatutodoInstitutoPortuguêsdeNegóciosSociais.docx / PDF

**Conteúdo Identificado:**
- Denominação, natureza jurídica e sede
- Fins e objetivos do Instituto
- Estrutura dos órgãos sociais (Assembleia Geral, Direção, Conselho Fiscal)
- Categorias de associados (8 tipos)
- Direitos e deveres dos associados
- Funcionamento dos órgãos sociais
- Regime económico e financeiro
- Disposições gerais

**Análise:**
Este é o documento fundamental e está completo para o registro inicial. Contém toda a estrutura legal necessária para constituição da IPSS.

### 1.2 Escopo Institucional

**Arquivo:** InstitutoPortuguêsdeNegóciosSociais–BureauSocial_EscopoInstitucional.pdf

**Conteúdo Identificado:**
- Visão geral do Instituto
- Áreas de atuação detalhadas (5 áreas)
- Alinhamento com ODS e princípios ESG
- Modelo de governança
- Estratégia de parcerias
- Fontes de financiamento

**Análise:**
Documento estratégico bem elaborado que serve como base para planejamento institucional. Fornece direcionamento claro para as atividades.

### 1.3 Documentos de Constituição

**Arquivo:** Documentos para constituição da Associação

**Conteúdo Presumido:**
- Ata de assembleia de constituição
- Lista de associados fundadores
- Declarações e documentos complementares

**Análise:**
Documentos necessários para o processo de registro junto às autoridades competentes.

## 2. Lacunas Identificadas

### 2.1 Documentos Legais e de Governança

**Faltam:**
1. **Regulamento Interno** - Detalhamento operacional dos estatutos
2. **Regulamento Eleitoral** - Procedimentos para eleição dos órgãos sociais
3. **Código de Conduta e Ética** - Princípios éticos para associados e colaboradores
4. **Política de Conflito de Interesses** - Prevenção e gestão de conflitos
5. **Regulamento de Quotas e Contribuições** - Valores e formas de pagamento
6. **Política de Admissão e Exclusão de Associados** - Critérios e procedimentos
7. **Regulamento do Conselho de Profissionais** - Funcionamento e atribuições
8. **Política de Proteção de Dados (RGPD)** - Conformidade com legislação europeia

### 2.2 Documentos Estratégicos e de Planejamento

**Faltam:**
1. **Plano Estratégico Trienal (2025-2027)** - Objetivos e metas de médio prazo
2. **Plano de Atividades Anual (2025)** - Programação detalhada do primeiro ano
3. **Orçamento Anual (2025)** - Previsão de receitas e despesas
4. **Plano de Captação de Recursos** - Estratégias de fundraising
5. **Plano de Comunicação e Marketing** - Estratégia de divulgação
6. **Plano de Gestão de Riscos** - Identificação e mitigação de riscos
7. **Política de Investimento Social** - Critérios para alocação de recursos
8. **Matriz de Indicadores de Impacto** - KPIs para mensuração de resultados

### 2.3 Documentos Operacionais

**Faltam:**
1. **Manual de Procedimentos Administrativos** - Rotinas operacionais
2. **Manual de Gestão Financeira** - Controles e procedimentos financeiros
3. **Política de Compras e Contratações** - Procedimentos de aquisição
4. **Manual de Gestão de Projetos** - Metodologia para execução de projetos
5. **Política de Voluntariado** - Gestão e coordenação de voluntários
6. **Manual de Gestão de Parcerias** - Procedimentos para estabelecer parcerias
7. **Política de Recursos Humanos** - Contratação, remuneração, benefícios
8. **Regulamento de Utilização de Instalações** - Uso de espaços e equipamentos

### 2.4 Documentos de Prestação de Contas e Transparência

**Faltam:**
1. **Modelo de Relatório Anual de Atividades** - Template padronizado
2. **Modelo de Relatório de Impacto Social** - Metodologia de mensuração
3. **Modelo de Demonstrações Financeiras** - Balanço, DRE, Fluxo de Caixa
4. **Política de Transparência e Acesso à Informação** - Disponibilização de dados
5. **Relatório ESG** - Reporte de práticas ambientais, sociais e de governança
6. **Plano de Auditoria Interna** - Procedimentos de controle interno

### 2.5 Documentos de Comunicação e Marketing

**Faltam:**
1. **Manual de Identidade Visual** - Uso de logotipo, cores, tipografia
2. **Apresentação Institucional (Pitch Deck)** - Para apresentação a parceiros
3. **One Pager Institucional** - Resumo visual de uma página
4. **Kit de Imprensa (Press Kit)** - Materiais para mídia
5. **Modelos de Comunicação** - Templates de emails, cartas, comunicados
6. **Estratégia de Redes Sociais** - Conteúdo e calendário editorial
7. **Política de Comunicação Institucional** - Diretrizes de comunicação
8. **Materiais de Captação de Associados** - Folhetos, apresentações

### 2.6 Documentos para Parcerias e Projetos

**Faltam:**
1. **Modelo de Protocolo de Parceria** - Template para acordos com parceiros
2. **Modelo de Memorando de Entendimento (MoU)** - Para colaborações iniciais
3. **Modelo de Termo de Cooperação** - Para projetos específicos
4. **Modelo de Proposta de Projeto** - Para candidaturas a financiamento
5. **Modelo de Relatório de Projeto** - Prestação de contas de projetos
6. **Ficha de Avaliação de Parceiros** - Critérios de seleção
7. **Modelo de Carta de Intenção** - Para manifestação de interesse
8. **Due Diligence Checklist** - Para avaliação de parceiros

### 2.7 Documentos para Associados

**Faltam:**
1. **Ficha de Candidatura a Associado** - Formulário de inscrição
2. **Termo de Adesão** - Compromisso do associado
3. **Manual do Associado** - Guia com direitos, deveres e benefícios
4. **Certificado de Associado** - Documento de reconhecimento
5. **Cartão de Associado** - Identificação física
6. **Carta de Boas-Vindas** - Comunicação inicial
7. **Modelo de Convocatória para Assembleia Geral** - Template oficial
8. **Modelo de Ata de Assembleia Geral** - Template padronizado

### 2.8 Documentos Específicos por Área de Atuação

**Habitação Social:**
1. Protocolo Modelo com Autarquias
2. Ficha de Avaliação de Imóveis
3. Critérios de Seleção de Beneficiários
4. Contrato de Arrendamento Social

**Empreendedorismo Social:**
1. Ficha de Candidatura a Incubação
2. Critérios de Seleção de Negócios Sociais
3. Programa de Mentoria
4. Modelo de Plano de Negócios Social

**Sustentabilidade ESG:**
1. Metodologia de Avaliação ESG
2. Modelo de Relatório de Sustentabilidade
3. Certificação de Práticas Sustentáveis
4. Programa de Formação Verde

**Economia Circular:**
1. Critérios de Projetos de Economia Circular
2. Modelo de Avaliação de Impacto Ambiental
3. Programa de Emprego Verde
4. Parcerias com Setor Privado

**Educação para Cidadania:**
1. Programa de Formação Cívica
2. Metodologia de Educação Não Formal
3. Avaliação de Impacto Educativo
4. Parcerias com Escolas

## 3. Priorização de Documentos

### 3.1 Prioridade ALTA (Necessários para Registro e Início de Operações)

1. Regulamento Interno
2. Plano de Atividades Anual 2025
3. Orçamento Anual 2025
4. Regulamento de Quotas e Contribuições
5. Ficha de Candidatura a Associado
6. Manual do Associado
7. Política de Proteção de Dados (RGPD)
8. Código de Conduta e Ética
9. Apresentação Institucional (Pitch Deck)
10. Modelos de Protocolo de Parceria

### 3.2 Prioridade MÉDIA (Necessários nos Primeiros 3 Meses)

1. Plano Estratégico Trienal
2. Plano de Captação de Recursos
3. Plano de Comunicação e Marketing
4. Manual de Procedimentos Administrativos
5. Manual de Gestão Financeira
6. Política de Voluntariado
7. Manual de Gestão de Projetos
8. Modelo de Relatório Anual
9. Manual de Identidade Visual
10. Materiais de Captação de Associados

### 3.3 Prioridade BAIXA (Desenvolvimento Progressivo)

1. Documentos específicos por área de atuação
2. Políticas operacionais detalhadas
3. Manuais especializados
4. Ferramentas de avaliação avançadas
5. Sistemas de certificação

## 4. Informações Necessárias do Usuário

Para elaborar os documentos de forma completa e personalizada, preciso das seguintes informações:

### 4.1 Informações Institucionais Básicas

1. **Data de Constituição:** Quando foi ou será a assembleia de constituição?
2. **Número de Associados Fundadores:** Quantos são?
3. **Composição da Direção:** Quem são os membros da primeira Direção?
4. **Composição do Conselho Fiscal:** Quem são os membros?
5. **Morada Completa da Sede:** Confirmar endereço exato
6. **Contactos:** Telefone e email oficiais
7. **NIPC/NIF:** Já possui número de identificação fiscal?
8. **Conta Bancária:** Já foi aberta conta bancária institucional?

### 4.2 Informações Financeiras

1. **Valor das Quotas:** Quanto será cobrado de cada categoria de associado?
2. **Orçamento Inicial:** Qual o capital inicial disponível?
3. **Fontes de Financiamento Previstas:** Quais as principais fontes para 2025?
4. **Despesas Previstas:** Principais categorias de despesa (aluguel, salários, etc.)
5. **Projeção de Receitas:** Estimativa de receitas para o primeiro ano

### 4.3 Informações sobre Projetos e Atividades

1. **Projetos Prioritários 2025:** Quais os 3-5 projetos principais do primeiro ano?
2. **Parcerias Já Estabelecidas:** Existem parceiros confirmados?
3. **Parcerias em Negociação:** Com quem estão conversando?
4. **Financiamentos Solicitados:** Já submeteram candidaturas?
5. **Cronograma de Implementação:** Quando pretendem iniciar cada área de atuação?

### 4.4 Informações sobre Recursos Humanos

1. **Equipa Inicial:** Quantas pessoas trabalharão no Instituto inicialmente?
2. **Funções:** Quais as funções previstas (diretor executivo, coordenadores, etc.)?
3. **Regime de Contratação:** CLT, prestação de serviços, voluntariado?
4. **Política Salarial:** Já definiram faixas salariais?
5. **Voluntários:** Quantos voluntários pretendem ter?

### 4.5 Informações sobre Governança

1. **Frequência de Reuniões:** Com que frequência a Direção se reunirá?
2. **Assembleia Geral:** Quando será a primeira AG ordinária?
3. **Mandatos:** Duração dos mandatos dos órgãos sociais (já definido nos estatutos?)
4. **Comissões:** Pretendem criar comissões especializadas?
5. **Conselho Consultivo:** Haverá um conselho consultivo ou de profissionais?

### 4.6 Informações sobre Comunicação

1. **Redes Sociais:** Quais plataformas pretendem usar?
2. **Frequência de Comunicação:** Com que frequência comunicarão com associados?
3. **Eventos:** Planejam realizar eventos no primeiro ano?
4. **Publicações:** Pretendem ter newsletter, blog, relatórios regulares?
5. **Identidade Visual:** Além dos logotipos, há outros elementos definidos?

## 5. Metodologia de Trabalho

### 5.1 Abordagem

Vou elaborar os documentos em fases, começando pelos de prioridade alta e coletando informações conforme necessário. Cada documento será:

1. **Estruturado:** Com seções claras e numeração adequada
2. **Completo:** Com todo o conteúdo necessário
3. **Personalizável:** Com campos para preencher informações específicas
4. **Profissional:** Formatação adequada e linguagem técnica apropriada
5. **Prático:** Pronto para uso imediato

### 5.2 Formato dos Documentos

- **Documentos Legais:** Formato formal, linguagem jurídica apropriada
- **Documentos Estratégicos:** Formato executivo, com gráficos e tabelas
- **Documentos Operacionais:** Formato prático, tipo manual/guia
- **Documentos de Comunicação:** Formato visual, design atrativo

### 5.3 Entrega

Todos os documentos serão entregues em:
- **Formato Markdown:** Para fácil edição
- **Formato Word:** Para uso profissional
- **Formato PDF:** Para distribuição oficial

## 6. Próximos Passos

1. **Apresentar Lista Completa:** Vou preparar uma lista detalhada de todos os documentos a serem elaborados
2. **Coletar Informações:** Farei perguntas específicas para personalizar os documentos
3. **Elaborar Documentos:** Começarei pelos de prioridade alta
4. **Revisar e Ajustar:** Incorporarei feedback e farei ajustes necessários
5. **Entregar Pacote Completo:** Fornecerei todos os documentos organizados e prontos para uso

---

**Nota:** Esta análise serve como base para o trabalho de elaboração documental. Aguardo suas respostas às perguntas acima para iniciar a produção dos documentos personalizados.

