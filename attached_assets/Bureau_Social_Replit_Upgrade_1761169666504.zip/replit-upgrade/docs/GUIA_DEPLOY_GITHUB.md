# 🚀 Guia Completo de Deploy via GitHub + Netlify

## ✅ Repositório Git Configurado!

Já configurei o repositório Git local com todos os arquivos do projeto!

**Status:**
- ✅ Git inicializado
- ✅ .gitignore configurado
- ✅ README.md criado
- ✅ Commit inicial feito
- ⏳ Aguardando push para GitHub

---

## 📋 OPÇÃO 1: Deploy Automático (Recomendado)

### Passo 1: Criar Repositório no GitHub

**Via Interface Web (Mais Fácil):**

1. Acesse: https://github.com/new
2. **Nome do repositório:** `bureau-social`
3. **Descrição:** `Site institucional e portal de associados do Bureau Social`
4. **Visibilidade:** Private (recomendado) ou Public
5. **NÃO marque** "Initialize with README" (já temos um)
6. Clique em **"Create repository"**

### Passo 2: Fazer Push do Código

Após criar o repositório, o GitHub mostrará instruções. Use estas:

```bash
cd /home/ubuntu/bureau-social-website

# Adicionar remote (substitua SEU_USUARIO pelo seu username do GitHub)
git remote add origin https://github.com/SEU_USUARIO/bureau-social.git

# Fazer push
git branch -M main
git push -u origin main
```

**Nota:** Você precisará autenticar com seu token do GitHub.

### Passo 3: Conectar ao Netlify

1. Acesse: https://app.netlify.com/
2. Faça login (ou crie conta gratuita)
3. Clique em **"Add new site"** → **"Import an existing project"**
4. Escolha **"Deploy with GitHub"**
5. Autorize o Netlify a acessar seus repositórios
6. Selecione o repositório **`bureau-social`**
7. Configure:
   - **Branch to deploy:** `main`
   - **Build command:** `pnpm build`
   - **Publish directory:** `dist`
8. **Variáveis de Ambiente** (clique em "Advanced"):
   - `VITE_API_URL`: `https://sua-api-url.com` (configurar depois)
9. Clique em **"Deploy site"**

**Pronto!** Em 2-3 minutos seu site estará online!

---

## 📋 OPÇÃO 2: Deploy Manual Rápido

Se preferir não usar GitHub agora:

### Via Netlify Drop

1. Acesse: https://app.netlify.com/drop
2. Arraste o arquivo **Bureau_Social_Deploy.zip**
3. Aguarde 30 segundos
4. Site online!

**Vantagem:** Super rápido  
**Desvantagem:** Sem controle de versão, precisa fazer upload manual a cada mudança

---

## 🔧 OPÇÃO 3: Deploy via Vercel

### Com GitHub:

1. Acesse: https://vercel.com/new
2. Conecte com GitHub
3. Importe o repositório `bureau-social`
4. Configure:
   - **Framework Preset:** Vite
   - **Build Command:** `pnpm build`
   - **Output Directory:** `dist`
5. **Environment Variables:**
   - `VITE_API_URL`: `https://sua-api-url.com`
6. Deploy!

---

## 🌐 Configurar Backend em Produção

O backend precisa estar hospedado separadamente. Opções:

### Opção A: Railway (Recomendado)

1. Acesse: https://railway.app/
2. Conecte com GitHub
3. **"New Project"** → **"Deploy from GitHub repo"**
4. Selecione `bureau-social`
5. Configure:
   - **Root Directory:** `/`
   - **Start Command:** `node server/index.cjs`
6. **Variables:**
   - `RESEND_API_KEY`: `re_FFwARftH_FUmYmbrYbkH4THw45yb2Dywa`
   - `JWT_SECRET`: `bureau_social_secret_2025`
   - `PORT`: `3001`
7. Deploy!
8. Copie a URL gerada (ex: `https://bureau-social-production.up.railway.app`)

### Opção B: Render

1. Acesse: https://render.com/
2. **"New"** → **"Web Service"**
3. Conecte GitHub e selecione repositório
4. Configure:
   - **Build Command:** `pnpm install`
   - **Start Command:** `node server/index.cjs`
   - **Environment Variables:** (mesmas acima)
5. Deploy!

### Opção C: Heroku

```bash
# Instalar Heroku CLI
curl https://cli-assets.heroku.com/install.sh | sh

# Login
heroku login

# Criar app
cd /home/ubuntu/bureau-social-website
heroku create bureau-social-api

# Configurar variáveis
heroku config:set RESEND_API_KEY=re_FFwARftH_FUmYmbrYbkH4THw45yb2Dywa
heroku config:set JWT_SECRET=bureau_social_secret_2025

# Deploy
git push heroku main
```

### Atualizar Frontend com URL do Backend

Depois de fazer deploy do backend:

1. Copie a URL do backend (ex: `https://bureau-social-api.railway.app`)
2. No Netlify/Vercel, vá em **"Site settings"** → **"Environment variables"**
3. Adicione/Atualize:
   - `VITE_API_URL`: `https://bureau-social-api.railway.app`
4. **"Trigger deploy"** para rebuild

---

## 🎯 Checklist Completo de Deploy

### Frontend (Netlify/Vercel):
- [ ] Código no GitHub
- [ ] Site conectado ao repositório
- [ ] Build command: `pnpm build`
- [ ] Publish directory: `dist`
- [ ] Variável `VITE_API_URL` configurada
- [ ] Deploy bem-sucedido
- [ ] Site acessível

### Backend (Railway/Render/Heroku):
- [ ] Código no GitHub (mesmo repositório)
- [ ] Web service criado
- [ ] Start command: `node server/index.cjs`
- [ ] Variáveis de ambiente configuradas:
  - [ ] `RESEND_API_KEY`
  - [ ] `JWT_SECRET`
  - [ ] `PORT` (se necessário)
- [ ] Deploy bem-sucedido
- [ ] API acessível (teste: `/api/health`)

### Banco de Dados:
- [ ] Para produção, migrar de SQLite para PostgreSQL
- [ ] Configurar variável `DATABASE_URL`
- [ ] Rodar migrações

### DNS e Domínio (Opcional):
- [ ] Comprar domínio (ex: bureausocial.pt)
- [ ] Configurar DNS no Netlify/Vercel
- [ ] Ativar HTTPS (automático)
- [ ] Configurar email profissional no Resend

---

## 🔑 Variáveis de Ambiente Necessárias

### Frontend (.env.production):
```env
VITE_API_URL=https://sua-api-backend.com
```

### Backend (.env):
```env
RESEND_API_KEY=re_FFwARftH_FUmYmbrYbkH4THw45yb2Dywa
JWT_SECRET=bureau_social_secret_2025
PORT=3001
DATABASE_URL=postgresql://... (se usar PostgreSQL)
```

---

## 📊 Monitoramento Pós-Deploy

### Testar Frontend:
```bash
curl https://seu-site.netlify.app/
```

### Testar Backend:
```bash
curl https://sua-api.railway.app/api/health
```

Deve retornar:
```json
{"status":"ok","message":"Bureau Social API is running"}
```

### Testar Login:
1. Acesse: `https://seu-site.netlify.app/login`
2. Use: `dmrdiego@gmail.com` / `Diego@1987`
3. Deve redirecionar para o portal

---

## 🚨 Troubleshooting

### "Build failed" no Netlify:
- Verifique se `pnpm-lock.yaml` está no repositório
- Confirme que `package.json` tem script `build`
- Veja os logs de build para erros específicos

### "API not responding":
- Verifique se o backend está rodando
- Confirme variáveis de ambiente
- Teste endpoint `/api/health`
- Veja logs do servidor

### "CORS error":
- Adicione o domínio do frontend nas configurações de CORS do backend
- Edite `server/index.cjs` e adicione o domínio em `cors({ origin: [...] })`

### "Email não enviado":
- Verifique API Key do Resend
- Confirme que o domínio está verificado (ou use onboarding@resend.dev)
- Veja logs do backend

---

## 💡 Dicas Importantes

1. **Sempre use HTTPS** (automático no Netlify/Vercel)
2. **Mantenha as API Keys seguras** (nunca no código, sempre em variáveis de ambiente)
3. **Faça backup do banco de dados** regularmente
4. **Use branches** para desenvolvimento (main para produção)
5. **Configure CI/CD** para testes automáticos
6. **Monitore logs** para detectar erros

---

## 🎉 Após o Deploy

### Próximos Passos:

1. **Testar todas as funcionalidades:**
   - Cadastro de associado
   - Login
   - Portal
   - Envio de emails
   - Download de documentos

2. **Configurar domínio personalizado:**
   - Comprar `bureausocial.pt`
   - Configurar DNS
   - Ativar HTTPS

3. **Configurar email profissional:**
   - Verificar domínio no Resend
   - Usar `noreply@bureausocial.pt`

4. **Adicionar conteúdo:**
   - Publicar primeiras notícias
   - Adicionar fotos reais
   - Atualizar informações

5. **Divulgar:**
   - Redes sociais
   - Email marketing
   - Eventos

---

## 📞 Precisa de Ajuda?

Se encontrar problemas:

1. Consulte os logs do Netlify/Railway
2. Teste localmente primeiro
3. Verifique variáveis de ambiente
4. Confirme que o código está atualizado no GitHub

---

## 🔗 Links Úteis

- **Netlify:** https://www.netlify.com/
- **Vercel:** https://vercel.com/
- **Railway:** https://railway.app/
- **Render:** https://render.com/
- **Heroku:** https://www.heroku.com/
- **GitHub:** https://github.com/
- **Resend:** https://resend.com/

---

**Boa sorte com o deploy! 🚀**

O repositório Git está pronto. Agora é só seguir os passos acima!

