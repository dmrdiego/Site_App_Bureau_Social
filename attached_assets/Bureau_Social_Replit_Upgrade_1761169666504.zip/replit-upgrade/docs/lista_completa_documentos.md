# Lista Completa de Documentos - Bureau Social

## Resumo Executivo

Identificamos **60 documentos** essenciais para o registro e operação completa do Instituto Português de Negócios Sociais - Bureau Social. Estes documentos estão organizados em 8 categorias e 3 níveis de prioridade.

**Total de Documentos por Prioridade:**
- **Prioridade ALTA (Imediatos):** 15 documentos
- **Prioridade MÉDIA (3 meses):** 20 documentos  
- **Prioridade BAIXA (6-12 meses):** 25 documentos

---

## CATEGORIA 1: DOCUMENTOS LEGAIS E DE GOVERNANÇA

### Prioridade ALTA (5 documentos)

**1.1 Regulamento Interno**
- Detalhamento operacional dos estatutos
- Procedimentos administrativos gerais
- Normas de funcionamento dos órgãos sociais
- **Páginas estimadas:** 15-20

**1.2 Código de Conduta e Ética**
- Princípios éticos para associados e colaboradores
- Normas de comportamento profissional
- Procedimentos para denúncias
- **Páginas estimadas:** 8-10

**1.3 Política de Proteção de Dados (RGPD)**
- Conformidade com legislação europeia
- Procedimentos de coleta e tratamento de dados
- Direitos dos titulares de dados
- **Páginas estimadas:** 12-15

**1.4 Regulamento de Quotas e Contribuições**
- Valores de quotas por categoria de associado
- Formas e prazos de pagamento
- Isenções e descontos
- **Páginas estimadas:** 5-8

**1.5 Política de Admissão e Exclusão de Associados**
- Critérios de admissão por categoria
- Procedimentos de candidatura
- Motivos e procedimentos de exclusão
- **Páginas estimadas:** 8-10

### Prioridade MÉDIA (3 documentos)

**1.6 Regulamento Eleitoral**
- Procedimentos para eleição dos órgãos sociais
- Calendário eleitoral
- Regras de candidatura e votação
- **Páginas estimadas:** 10-12

**1.7 Política de Conflito de Interesses**
- Identificação de situações de conflito
- Procedimentos de declaração
- Medidas preventivas e corretivas
- **Páginas estimadas:** 6-8

**1.8 Regulamento do Conselho de Profissionais**
- Composição e atribuições
- Funcionamento e reuniões
- Relação com outros órgãos
- **Páginas estimadas:** 8-10

---

## CATEGORIA 2: DOCUMENTOS ESTRATÉGICOS E DE PLANEJAMENTO

### Prioridade ALTA (3 documentos)

**2.1 Plano de Atividades Anual 2025**
- Objetivos específicos para o primeiro ano
- Programação detalhada de atividades por área
- Cronograma de implementação
- Responsáveis e recursos necessários
- **Páginas estimadas:** 20-25

**2.2 Orçamento Anual 2025**
- Previsão de receitas por fonte
- Previsão de despesas por categoria
- Fluxo de caixa mensal
- Indicadores financeiros
- **Páginas estimadas:** 15-20 + planilhas

**2.3 Plano de Captação de Recursos**
- Estratégias de fundraising
- Fontes de financiamento prioritárias
- Calendário de candidaturas
- Metas de captação
- **Páginas estimadas:** 15-18

### Prioridade MÉDIA (5 documentos)

**2.4 Plano Estratégico Trienal (2025-2027)**
- Visão de médio prazo
- Objetivos estratégicos por área
- Metas quantitativas e qualitativas
- Indicadores de sucesso
- **Páginas estimadas:** 30-40

**2.5 Plano de Comunicação e Marketing**
- Estratégia de comunicação institucional
- Plano de redes sociais
- Calendário editorial
- Orçamento de comunicação
- **Páginas estimadas:** 20-25

**2.6 Plano de Gestão de Riscos**
- Identificação de riscos por categoria
- Análise de probabilidade e impacto
- Medidas de mitigação
- Plano de contingência
- **Páginas estimadas:** 15-20

**2.7 Política de Investimento Social**
- Critérios para alocação de recursos
- Áreas prioritárias de investimento
- Processo de aprovação de projetos
- Avaliação de retorno social
- **Páginas estimadas:** 10-12

**2.8 Matriz de Indicadores de Impacto**
- KPIs por área de atuação
- Metodologia de mensuração
- Frequência de reporte
- Metas de impacto
- **Páginas estimadas:** 12-15

---

## CATEGORIA 3: DOCUMENTOS OPERACIONAIS

### Prioridade MÉDIA (5 documentos)

**3.1 Manual de Procedimentos Administrativos**
- Rotinas operacionais diárias
- Fluxos de trabalho
- Formulários e modelos
- Responsabilidades por função
- **Páginas estimadas:** 25-30

**3.2 Manual de Gestão Financeira**
- Controles financeiros
- Procedimentos de pagamento e recebimento
- Gestão de caixa
- Prestação de contas
- **Páginas estimadas:** 20-25

**3.3 Manual de Gestão de Projetos**
- Metodologia de gestão de projetos
- Ciclo de vida do projeto
- Ferramentas e templates
- Monitoramento e avaliação
- **Páginas estimadas:** 25-30

**3.4 Política de Voluntariado**
- Recrutamento e seleção de voluntários
- Direitos e deveres
- Formação e acompanhamento
- Reconhecimento e certificação
- **Páginas estimadas:** 12-15

**3.5 Manual de Gestão de Parcerias**
- Identificação e seleção de parceiros
- Formalização de parcerias
- Gestão do relacionamento
- Avaliação de parcerias
- **Páginas estimadas:** 15-18

### Prioridade BAIXA (3 documentos)

**3.6 Política de Compras e Contratações**
- Procedimentos de aquisição
- Critérios de seleção de fornecedores
- Limites de aprovação
- Compras sustentáveis
- **Páginas estimadas:** 10-12

**3.7 Política de Recursos Humanos**
- Recrutamento e seleção
- Remuneração e benefícios
- Avaliação de desempenho
- Desenvolvimento profissional
- **Páginas estimadas:** 18-22

**3.8 Regulamento de Utilização de Instalações**
- Uso de espaços físicos
- Reserva de salas
- Normas de segurança
- Responsabilidades
- **Páginas estimadas:** 8-10

---

## CATEGORIA 4: DOCUMENTOS DE PRESTAÇÃO DE CONTAS

### Prioridade MÉDIA (3 documentos)

**4.1 Modelo de Relatório Anual de Atividades**
- Template padronizado
- Estrutura de conteúdo
- Indicadores obrigatórios
- Design e formatação
- **Páginas estimadas:** Template de 40-50 páginas

**4.2 Modelo de Relatório de Impacto Social**
- Metodologia de mensuração de impacto
- Indicadores por área de atuação
- Casos de sucesso
- Visualização de dados
- **Páginas estimadas:** Template de 30-40 páginas

**4.3 Política de Transparência e Acesso à Informação**
- Informações públicas obrigatórias
- Canais de acesso
- Prazos de resposta
- Proteção de dados sensíveis
- **Páginas estimadas:** 8-10

### Prioridade BAIXA (3 documentos)

**4.4 Modelo de Demonstrações Financeiras**
- Balanço patrimonial
- Demonstração de resultados
- Fluxo de caixa
- Notas explicativas
- **Páginas estimadas:** Templates + 15-20 páginas

**4.5 Relatório ESG**
- Práticas ambientais
- Impacto social
- Governança corporativa
- Alinhamento com padrões internacionais
- **Páginas estimadas:** 35-45

**4.6 Plano de Auditoria Interna**
- Escopo de auditoria
- Frequência e procedimentos
- Relatórios de auditoria
- Ações corretivas
- **Páginas estimadas:** 12-15

---

## CATEGORIA 5: DOCUMENTOS DE COMUNICAÇÃO E MARKETING

### Prioridade ALTA (2 documentos)

**5.1 Apresentação Institucional (Pitch Deck)**
- Apresentação de 15-20 slides
- Para parceiros, financiadores e associados
- Design profissional
- Versões PT e EN
- **Slides:** 15-20

**5.2 One Pager Institucional**
- Resumo visual de uma página
- Informações essenciais
- Design impactante
- Versões PT e EN
- **Páginas:** 1 (frente e verso)

### Prioridade MÉDIA (4 documentos)

**5.3 Manual de Identidade Visual**
- Uso de logotipos
- Paleta de cores
- Tipografia
- Aplicações corretas e incorretas
- **Páginas estimadas:** 30-40

**5.4 Kit de Imprensa (Press Kit)**
- Comunicados de imprensa
- Biografias de líderes
- Imagens em alta resolução
- Dados e estatísticas
- **Páginas estimadas:** 20-25

**5.5 Modelos de Comunicação**
- Templates de emails
- Modelos de cartas oficiais
- Comunicados internos
- Newsletters
- **Páginas estimadas:** 15-20 templates

**5.6 Materiais de Captação de Associados**
- Folhetos informativos
- Apresentação sobre benefícios
- Formulários de inscrição
- Testemunhos
- **Páginas estimadas:** 10-15

### Prioridade BAIXA (2 documentos)

**5.7 Estratégia de Redes Sociais**
- Plano de conteúdo
- Calendário editorial
- Diretrizes de publicação
- Métricas de sucesso
- **Páginas estimadas:** 15-20

**5.8 Política de Comunicação Institucional**
- Diretrizes de comunicação externa
- Porta-vozes oficiais
- Gestão de crises
- Relacionamento com mídia
- **Páginas estimadas:** 12-15

---

## CATEGORIA 6: DOCUMENTOS PARA PARCERIAS E PROJETOS

### Prioridade ALTA (2 documentos)

**6.1 Modelo de Protocolo de Parceria**
- Template para acordos formais
- Cláusulas essenciais
- Direitos e obrigações
- Vigência e rescisão
- **Páginas estimadas:** 8-12

**6.2 Modelo de Proposta de Projeto**
- Template para candidaturas a financiamento
- Estrutura padronizada
- Orçamento detalhado
- Indicadores de impacto
- **Páginas estimadas:** 15-20

### Prioridade MÉDIA (2 documentos)

**6.3 Modelo de Memorando de Entendimento (MoU)**
- Para colaborações iniciais
- Intenções e objetivos
- Não vinculativo
- **Páginas estimadas:** 4-6

**6.4 Ficha de Avaliação de Parceiros**
- Critérios de seleção
- Scoring de parceiros
- Due diligence simplificada
- **Páginas estimadas:** 3-5

### Prioridade BAIXA (4 documentos)

**6.5 Modelo de Termo de Cooperação**
- Para projetos específicos
- Escopo detalhado
- Cronograma e entregas
- **Páginas estimadas:** 6-10

**6.6 Modelo de Relatório de Projeto**
- Prestação de contas de projetos
- Resultados alcançados
- Lições aprendidas
- **Páginas estimadas:** 10-15

**6.7 Modelo de Carta de Intenção**
- Manifestação de interesse
- Termos preliminares
- **Páginas estimadas:** 2-3

**6.8 Due Diligence Checklist**
- Avaliação completa de parceiros
- Documentos necessários
- Análise de riscos
- **Páginas estimadas:** 5-8

---

## CATEGORIA 7: DOCUMENTOS PARA ASSOCIADOS

### Prioridade ALTA (3 documentos)

**7.1 Ficha de Candidatura a Associado**
- Formulário completo de inscrição
- Dados pessoais e profissionais
- Categoria pretendida
- Declarações necessárias
- **Páginas estimadas:** 3-5

**7.2 Manual do Associado**
- Guia completo para associados
- Direitos e deveres
- Benefícios e serviços
- Procedimentos importantes
- **Páginas estimadas:** 20-25

**7.3 Termo de Adesão**
- Compromisso formal do associado
- Aceitação dos estatutos
- Autorização de dados
- **Páginas estimadas:** 2-3

### Prioridade MÉDIA (2 documentos)

**7.4 Carta de Boas-Vindas**
- Comunicação inicial para novos associados
- Próximos passos
- Contatos importantes
- **Páginas estimadas:** 2

**7.5 Modelo de Convocatória para Assembleia Geral**
- Template oficial
- Informações obrigatórias
- Ordem de trabalhos
- **Páginas estimadas:** 2-3

### Prioridade BAIXA (3 documentos)

**7.6 Certificado de Associado**
- Documento de reconhecimento
- Design personalizado
- **Páginas estimadas:** 1

**7.7 Cartão de Associado**
- Identificação física
- Design e especificações
- **Páginas estimadas:** 1 (especificações)

**7.8 Modelo de Ata de Assembleia Geral**
- Template padronizado
- Estrutura legal
- **Páginas estimadas:** 3-5

---

## CATEGORIA 8: DOCUMENTOS ESPECÍFICOS POR ÁREA DE ATUAÇÃO

### Habitação Social (Prioridade BAIXA - 4 documentos)

**8.1 Protocolo Modelo com Autarquias**
- Acordo para utilização de imóveis municipais
- **Páginas estimadas:** 8-12

**8.2 Ficha de Avaliação de Imóveis**
- Critérios técnicos de avaliação
- **Páginas estimadas:** 3-5

**8.3 Critérios de Seleção de Beneficiários**
- Sistema de pontuação
- **Páginas estimadas:** 5-8

**8.4 Contrato de Arrendamento Social**
- Modelo de contrato
- **Páginas estimadas:** 6-10

### Empreendedorismo Social (Prioridade BAIXA - 4 documentos)

**8.5 Ficha de Candidatura a Incubação**
- Formulário para negócios sociais
- **Páginas estimadas:** 4-6

**8.6 Critérios de Seleção de Negócios Sociais**
- Sistema de avaliação
- **Páginas estimadas:** 5-8

**8.7 Programa de Mentoria**
- Estrutura do programa
- **Páginas estimadas:** 10-12

**8.8 Modelo de Plano de Negócios Social**
- Template adaptado
- **Páginas estimadas:** 15-20

### Sustentabilidade ESG (Prioridade BAIXA - 4 documentos)

**8.9 Metodologia de Avaliação ESG**
- Framework de avaliação
- **Páginas estimadas:** 15-20

**8.10 Modelo de Relatório de Sustentabilidade**
- Template para empresas
- **Páginas estimadas:** 20-25

**8.11 Certificação de Práticas Sustentáveis**
- Critérios e processo
- **Páginas estimadas:** 10-12

**8.12 Programa de Formação Verde**
- Currículo de formação
- **Páginas estimadas:** 15-20

### Economia Circular (Prioridade BAIXA - 4 documentos)

**8.13 Critérios de Projetos de Economia Circular**
- Avaliação de projetos
- **Páginas estimadas:** 8-10

**8.14 Modelo de Avaliação de Impacto Ambiental**
- Metodologia simplificada
- **Páginas estimadas:** 12-15

**8.15 Programa de Emprego Verde**
- Estrutura do programa
- **Páginas estimadas:** 12-15

**8.16 Parcerias com Setor Privado**
- Modelo de colaboração
- **Páginas estimadas:** 8-10

### Educação para Cidadania (Prioridade BAIXA - 2 documentos)

**8.17 Programa de Formação Cívica**
- Currículo educativo
- **Páginas estimadas:** 15-20

**8.18 Metodologia de Educação Não Formal**
- Abordagens pedagógicas
- **Páginas estimadas:** 12-15

---

## RESUMO POR PRIORIDADE

### PRIORIDADE ALTA - 15 Documentos (Elaborar Imediatamente)

**Legais e Governança (5):**
1. Regulamento Interno
2. Código de Conduta e Ética
3. Política de Proteção de Dados (RGPD)
4. Regulamento de Quotas e Contribuições
5. Política de Admissão e Exclusão de Associados

**Estratégicos (3):**
6. Plano de Atividades Anual 2025
7. Orçamento Anual 2025
8. Plano de Captação de Recursos

**Comunicação (2):**
9. Apresentação Institucional (Pitch Deck)
10. One Pager Institucional

**Parcerias (2):**
11. Modelo de Protocolo de Parceria
12. Modelo de Proposta de Projeto

**Associados (3):**
13. Ficha de Candidatura a Associado
14. Manual do Associado
15. Termo de Adesão

**Total estimado de páginas:** 250-320 páginas

---

### PRIORIDADE MÉDIA - 20 Documentos (Elaborar em 3 Meses)

**Legais e Governança (3):**
16. Regulamento Eleitoral
17. Política de Conflito de Interesses
18. Regulamento do Conselho de Profissionais

**Estratégicos (5):**
19. Plano Estratégico Trienal (2025-2027)
20. Plano de Comunicação e Marketing
21. Plano de Gestão de Riscos
22. Política de Investimento Social
23. Matriz de Indicadores de Impacto

**Operacionais (5):**
24. Manual de Procedimentos Administrativos
25. Manual de Gestão Financeira
26. Manual de Gestão de Projetos
27. Política de Voluntariado
28. Manual de Gestão de Parcerias

**Prestação de Contas (3):**
29. Modelo de Relatório Anual de Atividades
30. Modelo de Relatório de Impacto Social
31. Política de Transparência e Acesso à Informação

**Comunicação (4):**
32. Manual de Identidade Visual
33. Kit de Imprensa (Press Kit)
34. Modelos de Comunicação
35. Materiais de Captação de Associados

**Parcerias (2):**
36. Modelo de Memorando de Entendimento (MoU)
37. Ficha de Avaliação de Parceiros

**Associados (2):**
38. Carta de Boas-Vindas
39. Modelo de Convocatória para Assembleia Geral

**Total estimado de páginas:** 450-550 páginas

---

### PRIORIDADE BAIXA - 25 Documentos (Elaborar em 6-12 Meses)

**Operacionais (3):**
40. Política de Compras e Contratações
41. Política de Recursos Humanos
42. Regulamento de Utilização de Instalações

**Prestação de Contas (3):**
43. Modelo de Demonstrações Financeiras
44. Relatório ESG
45. Plano de Auditoria Interna

**Comunicação (2):**
46. Estratégia de Redes Sociais
47. Política de Comunicação Institucional

**Parcerias (4):**
48. Modelo de Termo de Cooperação
49. Modelo de Relatório de Projeto
50. Modelo de Carta de Intenção
51. Due Diligence Checklist

**Associados (3):**
52. Certificado de Associado
53. Cartão de Associado
54. Modelo de Ata de Assembleia Geral

**Áreas Específicas (10):**
55-58. Habitação Social (4 documentos)
59-62. Empreendedorismo Social (4 documentos)
63-66. Sustentabilidade ESG (4 documentos)
67-70. Economia Circular (4 documentos)
71-72. Educação para Cidadania (2 documentos)

**Total estimado de páginas:** 350-450 páginas

---

## CRONOGRAMA DE ELABORAÇÃO SUGERIDO

### Fase 1 - Imediata (Semanas 1-4)
- Documentos de Prioridade ALTA (15 documentos)
- Foco: Viabilizar registro e início de operações

### Fase 2 - Consolidação (Meses 2-3)
- Documentos de Prioridade MÉDIA (20 documentos)
- Foco: Estruturar operações e comunicação

### Fase 3 - Expansão (Meses 4-12)
- Documentos de Prioridade BAIXA (25 documentos)
- Foco: Especialização por área de atuação

---

## PERGUNTAS PARA PERSONALIZAÇÃO

Para elaborar os documentos de forma completa e personalizada, preciso das seguintes informações. Vou organizá-las por tema para facilitar suas respostas:

### A. INFORMAÇÕES INSTITUCIONAIS BÁSICAS

1. Qual a data de constituição do Instituto (ou data prevista)?
2. Quantos são os associados fundadores?
3. Quem são os membros da primeira Direção (nomes e cargos)?
4. Quem são os membros do Conselho Fiscal?
5. Confirmar morada completa da sede: Rua do Salvador, 20, 1.º A, Lisboa?
6. Telefone e email oficiais do Instituto?
7. Já possui NIPC/NIF? Se sim, qual?
8. Já foi aberta conta bancária institucional? Em que banco?

### B. INFORMAÇÕES FINANCEIRAS

9. Qual o valor das quotas para cada categoria de associado?
10. Qual o capital inicial disponível?
11. Quais as principais fontes de financiamento previstas para 2025?
12. Principais categorias de despesa previstas (aluguel, salários, etc.)?
13. Estimativa de receitas totais para 2025?

### C. INFORMAÇÕES SOBRE PROJETOS

14. Quais os 3-5 projetos prioritários para 2025?
15. Existem parcerias já confirmadas? Com quem?
16. Existem parcerias em negociação? Com quem?
17. Já submeteram candidaturas a financiamento? Quais?
18. Quando pretendem iniciar cada área de atuação?

### D. INFORMAÇÕES SOBRE RECURSOS HUMANOS

19. Quantas pessoas trabalharão no Instituto inicialmente?
20. Quais as funções previstas (diretor executivo, coordenadores, etc.)?
21. Regime de contratação (CLT, prestação de serviços, voluntariado)?
22. Já definiram faixas salariais?
23. Quantos voluntários pretendem ter no primeiro ano?

### E. INFORMAÇÕES SOBRE GOVERNANÇA

24. Com que frequência a Direção se reunirá?
25. Quando será a primeira Assembleia Geral ordinária?
26. Duração dos mandatos dos órgãos sociais?
27. Pretendem criar comissões especializadas? Quais?
28. Haverá um Conselho Consultivo ou de Profissionais? Quem?

### F. INFORMAÇÕES SOBRE COMUNICAÇÃO

29. Quais redes sociais pretendem usar?
30. Com que frequência comunicarão com associados?
31. Planejam realizar eventos no primeiro ano? Quais?
32. Pretendem ter newsletter? Com que frequência?
33. Além dos logotipos, há outros elementos de identidade visual definidos?

---

## PRÓXIMOS PASSOS

1. **Responda às perguntas acima** - Quanto mais informações você fornecer, mais personalizados e completos serão os documentos

2. **Priorize os documentos** - Se houver algum documento específico que precise com urgência, me informe

3. **Início da elaboração** - Assim que tiver suas respostas, começarei a elaborar os documentos de Prioridade ALTA

4. **Revisão iterativa** - Você poderá revisar e solicitar ajustes em cada documento

5. **Entrega final** - Todos os documentos serão entregues em formatos editáveis (Markdown, Word) e PDF

---

**Aguardo suas respostas para iniciar a elaboração dos documentos! 📋**

