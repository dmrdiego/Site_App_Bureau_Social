# Estrutura e Arquitetura do Site - Bureau Social

## 1. Arquitetura de Informação

### 1.1 Estrutura de Navegação Principal

O site será estruturado com as seguintes seções principais:

**Menu Principal:**
1. **Início** - Página inicial com apresentação geral
2. **Quem Somos** - Informações institucionais
3. **Áreas de Atuação** - Projetos e iniciativas
4. **Associe-se** - Informações para potenciais associados
5. **Parcerias** - Parceiros institucionais e colaboradores
6. **Documentos** - Central de documentos institucionais
7. **Notícias** - Atualizações e eventos
8. **Contato** - Formulário e informações de contato

### 1.2 Mapa do Site Detalhado

#### Página Inicial (Home)
- Hero section com missão e tagline
- Apresentação visual do impacto
- Destaques das áreas de atuação (cards)
- Últimas notícias (3 mais recentes)
- Chamada para ação (Associe-se / Saiba Mais)
- Parceiros em destaque
- Footer com informações essenciais

#### Quem Somos
- **Sobre o Instituto**
  - Missão, Visão e Valores
  - História e Contexto
  - Princípios ESG e ODS
- **Órgãos Sociais**
  - Assembleia Geral
  - Direção
  - Conselho Fiscal
  - Secretaria Executiva
  - Conselho de Profissionais
- **Transparência**
  - Estatutos
  - Relatórios Anuais
  - Prestação de Contas

#### Áreas de Atuação
- **Habitação Social e Reutilização de Imóveis**
  - Descrição da área
  - Projetos em curso
  - Impacto gerado
- **Inovação e Empreendedorismo Social**
  - Programas de apoio
  - Incubação de negócios sociais
  - Formações e bootcamps
- **Sustentabilidade Ambiental e ESG**
  - Práticas sustentáveis
  - Projetos ambientais
  - Formação em competências verdes
- **Economia Circular e Emprego Verde**
  - Inclusão produtiva
  - Projetos de economia circular
  - Oportunidades de emprego
- **Educação para Cidadania**
  - Programas educativos
  - Voluntariado
  - Envolvimento comunitário

#### Associe-se
- **Categorias de Associados**
  - Fundadores
  - Efetivos
  - Contribuintes
  - Voluntários
  - Profissionais
  - Beneméritos
  - Patrocinadores
  - Institucionais
- **Benefícios de Ser Associado**
- **Como Se Associar** (formulário ou processo)
- **Direitos e Deveres**
- **Quotas e Contribuições**

#### Parcerias
- **Parceiros Institucionais**
  - Autarquias Locais
  - Governo Central
  - Organismos Europeus
- **Parceiros Estratégicos**
- **Financiadores**
- **Colaboradores**
- **Seja Parceiro** (formulário de interesse)

#### Documentos (Central)
- **Estatutos e Regulamentos**
  - Estatuto do Instituto
  - Regulamentos Internos
  - Documentos de Constituição
- **Relatórios e Contas**
  - Relatórios Anuais (por ano)
  - Demonstrações Financeiras
  - Planos de Atividades
- **Escopo Institucional**
  - Documentos estratégicos
  - Planos de ação
- **Publicações**
  - Estudos e pesquisas
  - Materiais educativos
- **Formulários**
  - Ficha de associado
  - Outros formulários úteis

#### Notícias
- Listagem de notícias e eventos
- Filtros por categoria/data
- Página individual para cada notícia
- Newsletter (inscrição)

#### Contato
- Formulário de contato
- Informações de contato (morada, telefone, email)
- Mapa de localização
- Redes sociais
- Horário de atendimento

## 2. Design e Identidade Visual

### 2.1 Paleta de Cores

**Cores Principais:**
- **Verde Primário** (#6B9F3E ou similar) - Sustentabilidade, crescimento, esperança
- **Verde Escuro** (#3D5A2B) - Profissionalismo, confiança
- **Branco** (#FFFFFF) - Limpeza, clareza
- **Cinza Claro** (#F5F5F5) - Backgrounds neutros

**Cores Secundárias:**
- **Preto** (#1A1A1A) - Texto principal, contraste
- **Cinza Médio** (#666666) - Texto secundário
- **Verde Claro** (#A8D08D) - Destaques, hover states

**Cores de Ação:**
- **Laranja/Coral** (#FF6B35) - CTAs, botões importantes
- **Azul** (#2E86AB) - Links, informações

### 2.2 Tipografia

**Fonte Principal (Títulos):**
- Poppins ou Montserrat (sans-serif moderna)
- Pesos: 600 (SemiBold), 700 (Bold)

**Fonte Secundária (Corpo):**
- Open Sans ou Inter (alta legibilidade)
- Pesos: 400 (Regular), 600 (SemiBold)

**Hierarquia:**
- H1: 48px (desktop) / 32px (mobile)
- H2: 36px (desktop) / 28px (mobile)
- H3: 28px (desktop) / 24px (mobile)
- H4: 24px (desktop) / 20px (mobile)
- Body: 16px (desktop) / 14px (mobile)
- Small: 14px (desktop) / 12px (mobile)

### 2.3 Componentes Visuais

**Elementos Gráficos:**
- Símbolo dos três círculos interligados (identidade visual)
- Ícones line-art para áreas de atuação
- Fotografias reais de projetos e pessoas
- Ilustrações minimalistas para conceitos abstratos

**Estilo Fotográfico:**
- Imagens autênticas de pessoas e comunidades
- Cores naturais e quentes
- Foco em rostos e emoções
- Diversidade e inclusão

## 3. Conteúdo das Páginas Principais

### 3.1 Página Inicial

**Hero Section:**
```
Título: "Impacto Positivo e Negócios Rentáveis"
Subtítulo: "Promovendo soluções inovadoras de economia social para a realização dos direitos sociais em Portugal"
CTA Primário: "Associe-se"
CTA Secundário: "Conheça Nosso Trabalho"
Background: Imagem de pessoas em comunidade ou projeto social
```

**Seção "Sobre Nós" (resumo):**
O Instituto Português de Negócios Sociais – Bureau Social é uma IPSS dedicada à promoção de soluções inovadoras de economia social que contribuem para a realização dos direitos sociais em Portugal. Atuamos nas áreas de habitação social, empreendedorismo social, sustentabilidade ambiental, economia circular e educação para a cidadania, sempre alinhados com os Objetivos de Desenvolvimento Sustentável da ONU e os princípios ESG.

**Áreas de Atuação (Cards):**
1. Habitação Social - Reabilitação de imóveis devolutos para famílias em risco
2. Empreendedorismo Social - Apoio a negócios sociais inovadores
3. Sustentabilidade ESG - Práticas sustentáveis e formação verde
4. Economia Circular - Inclusão produtiva e emprego verde
5. Educação Cidadã - Literacia cívica e participação democrática

**Números de Impacto:**
- [A preencher com dados reais quando disponíveis]
- Projetos em curso
- Famílias apoiadas
- Parceiros institucionais
- Associados

**Últimas Notícias:**
[3 cards com notícias mais recentes]

**Parceiros:**
Logos dos principais parceiros institucionais

### 3.2 Quem Somos - Conteúdo Detalhado

**Missão:**
Promover soluções inovadoras de economia social que contribuam para a realização dos direitos sociais em Portugal, dando expressão organizada ao dever moral de justiça e solidariedade, contribuindo para a efetivação dos direitos sociais dos cidadãos.

**Visão:**
Tornar-se referência nacional na construção de soluções sociais sustentáveis e inclusivas, inspirando outras organizações e mobilizando parcerias público-privadas para transformar comunidades e promover o desenvolvimento integral das pessoas.

**Valores:**
- **Solidariedade**: Compromisso com a justiça social e apoio mútuo
- **Inovação**: Busca constante por soluções criativas e eficazes
- **Transparência**: Prestação de contas clara e acessível
- **Sustentabilidade**: Práticas ambientalmente responsáveis e economicamente viáveis
- **Inclusão**: Promoção da diversidade e participação de todos
- **Autonomia**: Respeito pela autodeterminação das pessoas e comunidades
- **Democracia Participativa**: Envolvimento ativo dos associados e beneficiários

**Princípios ESG:**
O Instituto integra os princípios ESG (Environmental, Social and Governance) em todas as suas atividades:
- **Ambiental**: Projetos de economia circular, eficiência energética e sustentabilidade
- **Social**: Inclusão de grupos vulneráveis, habitação digna e educação para cidadania
- **Governança**: Transparência, prestação de contas e gestão democrática

**Alinhamento com ODS:**
Nosso trabalho está alinhado com os Objetivos de Desenvolvimento Sustentável da ONU, especialmente:
- ODS 1: Erradicação da Pobreza
- ODS 8: Trabalho Decente e Crescimento Económico
- ODS 11: Cidades e Comunidades Sustentáveis
- ODS 16: Paz, Justiça e Instituições Eficazes

### 3.3 Associe-se - Conteúdo Detalhado

**Introdução:**
Faça parte de uma comunidade comprometida com a transformação social em Portugal. Como associado do Bureau Social, você contribui diretamente para a construção de uma sociedade mais justa, inclusiva e sustentável.

**Categorias de Associados:**

**1. Fundadores**
Pessoas singulares que participaram na assembleia de constituição e se comprometem a colaborar na manutenção do Instituto.

**2. Efetivos**
Associados que, após anos de participação como contribuintes e sem infrações disciplinares, sejam convidados pela Direção e tenham a sua admissão homologada em Assembleia Geral.

**3. Contribuintes**
Pessoas singulares que solicitem adesão após a constituição e que paguem quotas associativas. Diferentes subcategorias podem ser definidas pela Direção.

**4. Voluntários**
Pessoas singulares que integrem as equipas de voluntariado do Instituto. Isentos de quotas.

**5. Profissionais**
Prestadores ou especialistas de diferentes áreas que colaborem em projetos do Instituto. Isentos de quotas.

**6. Beneméritos**
Pessoas singulares que tenham prestado serviços relevantes ou feito doações significativas. São convidados pela Direção e isentos de quotas.

**7. Patrocinadores**
Pessoas coletivas (empresas ou instituições) que apoiem financeiramente ou patrocinem regularmente as atividades do Instituto.

**8. Institucionais**
Pessoas coletivas do primeiro, segundo ou terceiro setor que participem em projetos do Instituto.

**Benefícios de Ser Associado:**
- Participação nas atividades e projetos do Instituto
- Direito a voto na Assembleia Geral (associados válidos)
- Acesso a formações e eventos exclusivos
- Networking com profissionais e organizações do setor social
- Contribuição direta para o impacto social em Portugal
- Certificado de associado
- Newsletter mensal com atualizações

**Como Se Associar:**
[Formulário online ou instruções para candidatura]

## 4. Funcionalidades Técnicas

### 4.1 Funcionalidades Essenciais

1. **Sistema de Gestão de Conteúdo (CMS)**
   - Atualização fácil de notícias e conteúdo
   - Gestão de documentos

2. **Central de Documentos**
   - Organização por categorias
   - Sistema de busca
   - Download de PDFs e documentos
   - Visualização inline quando possível

3. **Formulários**
   - Formulário de contato
   - Formulário de candidatura a associado
   - Formulário de interesse em parcerias
   - Newsletter signup

4. **Área de Notícias/Blog**
   - Sistema de publicação de notícias
   - Categorização
   - Imagens destacadas
   - Compartilhamento em redes sociais

5. **Responsividade**
   - Design totalmente responsivo
   - Mobile-first approach
   - Otimização para tablets

6. **SEO**
   - Meta tags otimizadas
   - URLs amigáveis
   - Sitemap XML
   - Schema markup para organizações sem fins lucrativos

7. **Acessibilidade**
   - Conformidade WCAG 2.1 nível AA
   - Contraste adequado
   - Navegação por teclado
   - Textos alternativos em imagens

8. **Performance**
   - Otimização de imagens
   - Lazy loading
   - Minificação de CSS/JS
   - Cache adequado

### 4.2 Funcionalidades Desejáveis (Futuro)

1. **Área de Associado**
   - Login para associados
   - Dashboard personalizado
   - Histórico de contribuições

2. **Sistema de Doações Online**
   - Integração com gateway de pagamento
   - Doações únicas e recorrentes

3. **Calendário de Eventos**
   - Listagem de eventos
   - Inscrições online

4. **Galeria de Projetos**
   - Portfolio de projetos realizados
   - Histórias de impacto

## 5. Tecnologias Recomendadas

### 5.1 Stack Tecnológico

**Frontend:**
- React.js (biblioteca moderna e eficiente)
- HTML5 semântico
- CSS3 / Tailwind CSS (estilização responsiva)
- JavaScript ES6+

**Backend (se necessário):**
- Node.js / Express (leve e eficiente)
- ou Static Site Generator (Gatsby, Next.js)

**Hospedagem:**
- Plataforma de deploy (Vercel, Netlify, ou similar)
- CDN para assets estáticos

**Gestão de Conteúdo:**
- Sistema de arquivos para documentos
- JSON ou Markdown para conteúdo editável
- ou CMS headless (Strapi, Contentful) para gestão mais avançada

## 6. Priorização de Desenvolvimento

### Fase 1 (MVP - Minimum Viable Product)
- Página Inicial
- Quem Somos (básico)
- Áreas de Atuação (listagem)
- Associe-se (informações)
- Central de Documentos (básica)
- Contato
- Design responsivo
- SEO básico

### Fase 2 (Expansão)
- Notícias/Blog completo
- Parcerias (página dedicada)
- Formulários funcionais
- Newsletter
- Galeria de imagens
- Otimizações de performance

### Fase 3 (Avançado)
- Área de associado
- Sistema de doações
- Calendário de eventos
- Multilíngue (PT/EN)
- Integrações avançadas

## 7. Requisitos de Conteúdo

### Conteúdo a Ser Preparado:

**Textos:**
- Descrições completas de cada área de atuação
- Biografias dos membros dos órgãos sociais (se disponível)
- Textos para páginas institucionais
- Notícias iniciais (3-5)

**Imagens:**
- Fotografias de projetos e atividades
- Fotos de equipe e órgãos sociais
- Imagens para hero sections
- Ícones para áreas de atuação

**Documentos:**
- Estatutos (já disponível)
- Escopo Institucional (já disponível)
- Documentos de constituição (já disponível)
- Relatórios (quando disponíveis)

**Informações:**
- Dados de contato completos
- Links de redes sociais
- Logos de parceiros
- Informações sobre quotas e contribuições

