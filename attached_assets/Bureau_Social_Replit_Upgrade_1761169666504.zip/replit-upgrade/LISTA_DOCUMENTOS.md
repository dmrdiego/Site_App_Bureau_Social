# 📄 Lista Completa de Documentos - Bureau Social

## Total: 29 Documentos PDF

---

## 📋 Categorias

### 1. Estatutos e Regulamentos (7 documentos)

1. **Ata_Constituicao_Bureau_Social.pdf**
   - Ata de constituição da associação
   - Data: 21/10/2025
   - Membros fundadores e órgãos sociais

2. **Regulamento_Interno_Bureau_Social.pdf**
   - Regulamento operacional completo
   - Complementa os Estatutos

3. **Regulamento_Quotas_Contribuicoes_Bureau_Social.pdf**
   - Valores e regras de quotas
   - Por categoria de associado

4. **Regulamento_Eleitoral_Bureau_Social.pdf**
   - Processo eleitoral dos órgãos sociais

5. **Regulamento_Utilizacao_Instalacoes_Bureau_Social.pdf**
   - Regras de uso das instalações

6. **Ficha_Candidatura_Associado_Bureau_Social.pdf**
   - Formulário de candidatura

7. **Termo_Adesao_Associado_Bureau_Social.pdf**
   - Termo de compromisso

---

### 2. Governança e Ética (3 documentos)

8. **Codigo_Conduta_Etica_Bureau_Social.pdf**
   - 30 artigos de conduta ética
   - Valores e princípios

9. **Politica_Protecao_Dados_RGPD_Bureau_Social.pdf**
   - Conformidade com RGPD
   - Proteção de dados pessoais

10. **Politica_Conflito_Interesses_Bureau_Social.pdf**
    - Gestão de conflitos de interesse
    - Modelo de declaração

---

### 3. Planeamento e Estratégia (6 documentos)

11. **Plano_Atividades_2026_Bureau_Social.pdf**
    - Programação anual de atividades
    - Metas e objetivos

12. **Orcamento_2026_Bureau_Social.pdf**
    - Previsão de receitas e despesas
    - Capital inicial: €1.000

13. **Plano_Captacao_Recursos_2026_Bureau_Social.pdf**
    - Estratégias de financiamento
    - Fontes de receita

14. **Plano_Estrategico_Trienal_2026_2028_Bureau_Social.pdf**
    - Visão de 3 anos
    - Objetivos estratégicos

15. **Plano_Atividades_2025_Bureau_Social.pdf** (versão anterior)
16. **Orcamento_2025_Bureau_Social.pdf** (versão anterior)

---

### 4. Comunicação e Marketing (2 documentos)

17. **Plano_Comunicacao_Marketing_Bureau_Social.pdf**
    - Estratégia de comunicação
    - Redes sociais e branding

18. **Apresentacao_Institucional_Bureau_Social.pdf**
    - Pitch deck de 12 slides
    - Para parceiros e financiadores

---

### 5. Documentos Operacionais (4 documentos)

19. **Politica_Compras_Contratacoes_Bureau_Social.pdf**
    - Procedimentos de compras

20. **Politica_Recursos_Humanos_Bureau_Social.pdf**
    - Gestão de RH

21. **Manual_Procedimentos_Administrativos_Financeiros_Bureau_Social.pdf**
    - Procedimentos do dia-a-dia

22. **Plano_Voluntariado_Bureau_Social.pdf**
    - Gestão de voluntários

---

### 6. Para Associados (2 documentos)

23. **Manual_Associado_Bureau_Social.pdf**
    - Guia completo do associado
    - Direitos e deveres

24. **Relatorio_Atividades_Contas_Modelo_Bureau_Social.pdf**
    - Template de relatório anual

---

### 7. Prestação de Contas (1 documento)

25. **Plano_Captacao_Recursos_2025_Bureau_Social.pdf** (versão anterior)

---

### 8. Documentos de Parceria (4 documentos)

26. **Carta_Apresentacao_Institucional.pdf**
    - Carta formal de apresentação

27. **Proposta_Parceria_Estrategica.pdf**
    - Proposta detalhada de cooperação

28. **Termo_Cooperacao_Padrao.pdf**
    - Contrato de parceria (20 cláusulas)

29. **Ficha_Adesao_Parceiro.pdf**
    - Formulário de candidatura a parceiro

---

## 📊 Estatísticas

- **Total de páginas**: ~220 páginas
- **Tamanho total**: ~15 MB
- **Formatos**: PDF
- **Idioma**: Português
- **Status**: Prontos para uso

---

## 🔧 Como Usar

### No Replit:

1. Copie os PDFs para `public/documentos/`
2. Adicione ao seu sistema de documentos
3. Atualize o seed do banco de dados

### Exemplo de Seed:

```typescript
const documents = [
  {
    title: "Ata de Constituição",
    category: "estatutos",
    filename: "Ata_Constituicao_Bureau_Social.pdf",
    uploadedBy: 1
  },
  // ... adicione os 29 documentos
];
```

---

## 📁 Organização Recomendada

### Por Categoria:

```
public/documentos/
├── estatutos/
│   ├── Ata_Constituicao_Bureau_Social.pdf
│   ├── Regulamento_Interno_Bureau_Social.pdf
│   └── ...
├── governanca/
│   ├── Codigo_Conduta_Etica_Bureau_Social.pdf
│   └── ...
├── estrategia/
│   ├── Plano_Atividades_2026_Bureau_Social.pdf
│   └── ...
└── ...
```

---

## ✅ Checklist de Integração

- [ ] Copiar todos os 29 PDFs
- [ ] Organizar por categoria (opcional)
- [ ] Adicionar ao banco de dados
- [ ] Testar download
- [ ] Verificar permissões
- [ ] Atualizar UI

---

## 📖 Documentos Principais

### Para Associados:
- Manual do Associado
- Ficha de Candidatura
- Termo de Adesão

### Para Administração:
- Regulamento Interno
- Plano de Atividades
- Orçamento

### Para Parceiros:
- Carta de Apresentação
- Proposta de Parceria
- Termo de Cooperação

---

## 🎯 Próximos Passos

1. Integre os documentos ao seu sistema
2. Configure permissões de acesso
3. Adicione descrições no DB
4. Teste downloads
5. Organize por categoria

---

**Todos os documentos estão prontos e testados!** ✅

