import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import API_URL from '../config/api';

export default function PortalAssociado() {
  const navigate = useNavigate();
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const token = localStorage.getItem('token');
    
    if (!token) {
      navigate('/login');
      return;
    }

    // Buscar dados do usuário
    fetch(`${API_URL}/api/auth/me`, {
      headers: {
        'Authorization': `Bearer ${token}`
      }
    })
      .then(res => {
        if (!res.ok) throw new Error('Não autenticado');
        return res.json();
      })
      .then(data => {
        setUser(data.user);
        setLoading(false);
      })
      .catch(err => {
        console.error(err);
        localStorage.removeItem('token');
        localStorage.removeItem('user');
        navigate('/login');
      });
  }, [navigate]);

  const handleLogout = () => {
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    navigate('/login');
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-[#044050] mx-auto"></div>
          <p className="mt-4 text-gray-600">Carregando...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-[#044050] text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex justify-between items-center">
            <div>
              <h1 className="text-2xl font-bold">Portal do Associado</h1>
              <p className="text-sm text-gray-300 mt-1">Bem-vindo, {user?.name}!</p>
            </div>
            <div className="flex items-center space-x-4">
              <a href="/" className="text-white hover:text-gray-200">
                Voltar ao Site
              </a>
              <button
                onClick={handleLogout}
                className="bg-white text-[#044050] px-4 py-2 rounded-md text-sm font-medium hover:bg-gray-100"
              >
                Sair
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* User Info Card */}
        <div className="bg-white rounded-lg shadow p-6 mb-8">
          <h2 className="text-xl font-bold text-gray-900 mb-4">Informações da Conta</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <p className="text-sm font-medium text-gray-500">Nome</p>
              <p className="text-lg text-gray-900">{user?.name}</p>
            </div>
            <div>
              <p className="text-sm font-medium text-gray-500">Email</p>
              <p className="text-lg text-gray-900">{user?.email}</p>
            </div>
            <div>
              <p className="text-sm font-medium text-gray-500">Telefone</p>
              <p className="text-lg text-gray-900">{user?.phone || 'Não informado'}</p>
            </div>
            <div>
              <p className="text-sm font-medium text-gray-500">Categoria</p>
              <p className="text-lg text-gray-900 capitalize">{user?.category}</p>
            </div>
            <div>
              <p className="text-sm font-medium text-gray-500">Status</p>
              <span className={`inline-flex items-center px-3 py-1 rounded-full text-sm font-medium ${
                user?.status === 'active' ? 'bg-green-100 text-green-800' : 'bg-yellow-100 text-yellow-800'
              }`}>
                {user?.status === 'active' ? 'Ativo' : 'Pendente'}
              </span>
            </div>
            <div>
              <p className="text-sm font-medium text-gray-500">Membro desde</p>
              <p className="text-lg text-gray-900">
                {new Date(user?.created_at).toLocaleDateString('pt-PT')}
              </p>
            </div>
          </div>
        </div>

        {/* Quick Actions */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <div className="bg-white rounded-lg shadow p-6">
            <div className="flex items-center">
              <div className="flex-shrink-0">
                <svg className="h-8 w-8 text-[#044050]" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                </svg>
              </div>
              <div className="ml-4">
                <h3 className="text-lg font-medium text-gray-900">Documentos</h3>
                <p className="text-sm text-gray-500">Acesse atas e documentos</p>
              </div>
            </div>
            <div className="mt-4">
              <a href="/documentos" className="text-[#044050] hover:text-[#033040] text-sm font-medium">
                Ver documentos →
              </a>
            </div>
          </div>

          <div className="bg-white rounded-lg shadow p-6">
            <div className="flex items-center">
              <div className="flex-shrink-0">
                <svg className="h-8 w-8 text-[#044050]" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-3 7h3m-3 4h3m-6-4h.01M9 16h.01" />
                </svg>
              </div>
              <div className="ml-4">
                <h3 className="text-lg font-medium text-gray-900">Assembleias</h3>
                <p className="text-sm text-gray-500">Próximas reuniões</p>
              </div>
            </div>
            <div className="mt-4">
              <p className="text-sm text-gray-500">Em breve</p>
            </div>
          </div>

          <div className="bg-white rounded-lg shadow p-6">
            <div className="flex items-center">
              <div className="flex-shrink-0">
                <svg className="h-8 w-8 text-[#044050]" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                </svg>
              </div>
              <div className="ml-4">
                <h3 className="text-lg font-medium text-gray-900">Votações</h3>
                <p className="text-sm text-gray-500">Participe das decisões</p>
              </div>
            </div>
            <div className="mt-4">
              <p className="text-sm text-gray-500">Nenhuma votação ativa</p>
            </div>
          </div>
        </div>

        {/* Welcome Message */}
        <div className="bg-blue-50 border border-blue-200 rounded-lg p-6">
          <h3 className="text-lg font-medium text-blue-900 mb-2">
            Bem-vindo ao Portal do Associado!
          </h3>
          <p className="text-sm text-blue-700">
            Este é o seu espaço exclusivo para acessar documentos, participar de assembleias e votações,
            e acompanhar as atividades do Instituto Português de Negócios Sociais – Bureau Social.
          </p>
          <p className="text-sm text-blue-700 mt-2">
            Em breve, novas funcionalidades estarão disponíveis!
          </p>
        </div>
      </div>
    </div>
  );
}

