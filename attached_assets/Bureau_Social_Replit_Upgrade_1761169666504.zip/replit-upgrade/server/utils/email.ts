const { Resend } = require('resend');

const resend = new Resend(process.env.RESEND_API_KEY);

async function sendVerificationEmail(email, name, token) {
  try {
    const verificationUrl = `${process.env.VITE_APP_URL || 'http://localhost:5173'}/verificar-email?token=${token}`;
    
    const { data, error } = await resend.emails.send({
      from: 'Bureau Social <noreply@bureausocial.pt>',
      to: [email],
      subject: 'Confirme seu cadastro - Bureau Social',
      html: `
        <!DOCTYPE html>
        <html>
        <head>
          <meta charset="utf-8">
          <style>
            body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
            .container { max-width: 600px; margin: 0 auto; padding: 20px; }
            .header { background: #044050; color: white; padding: 20px; text-align: center; }
            .content { background: #f9f9f9; padding: 30px; }
            .button { display: inline-block; padding: 12px 30px; background: #044050; color: white; text-decoration: none; border-radius: 5px; margin: 20px 0; }
            .footer { text-align: center; padding: 20px; font-size: 12px; color: #666; }
          </style>
        </head>
        <body>
          <div class="container">
            <div class="header">
              <h1>Bureau Social</h1>
              <p>Impacto Positivo e Negócios Rentáveis</p>
            </div>
            <div class="content">
              <h2>Olá, ${name}!</h2>
              <p>Bem-vindo ao Instituto Português de Negócios Sociais – Bureau Social!</p>
              <p>Para completar seu cadastro e ativar sua conta, por favor clique no botão abaixo:</p>
              <p style="text-align: center;">
                <a href="${verificationUrl}" class="button">Confirmar Email</a>
              </p>
              <p>Ou copie e cole este link no seu navegador:</p>
              <p style="word-break: break-all; background: #fff; padding: 10px; border-left: 3px solid #044050;">
                ${verificationUrl}
              </p>
              <p><strong>Este link expira em 24 horas.</strong></p>
              <p>Se você não solicitou este cadastro, por favor ignore este email.</p>
            </div>
            <div class="footer">
              <p>Instituto Português de Negócios Sociais – Bureau Social</p>
              <p>Rua do Salvador, 20, 1.º A, 1100-383 Lisboa, Portugal</p>
              <p>+351 931 721 901 | info@bureausocial.pt</p>
            </div>
          </div>
        </body>
        </html>
      `
    });

    if (error) {
      console.error('Erro ao enviar email:', error);
      return { success: false, error };
    }

    console.log('✅ Email de verificação enviado para:', email);
    return { success: true, data };
  } catch (error) {
    console.error('Erro ao enviar email:', error);
    return { success: false, error: error.message };
  }
}

async function sendWelcomeEmail(email, name) {
  try {
    const { data, error } = await resend.emails.send({
      from: 'Bureau Social <noreply@bureausocial.pt>',
      to: [email],
      subject: 'Bem-vindo ao Bureau Social!',
      html: `
        <!DOCTYPE html>
        <html>
        <head>
          <meta charset="utf-8">
          <style>
            body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
            .container { max-width: 600px; margin: 0 auto; padding: 20px; }
            .header { background: #044050; color: white; padding: 20px; text-align: center; }
            .content { background: #f9f9f9; padding: 30px; }
            .footer { text-align: center; padding: 20px; font-size: 12px; color: #666; }
          </style>
        </head>
        <body>
          <div class="container">
            <div class="header">
              <h1>Bureau Social</h1>
              <p>Impacto Positivo e Negócios Rentáveis</p>
            </div>
            <div class="content">
              <h2>Parabéns, ${name}!</h2>
              <p>Seu cadastro foi confirmado com sucesso!</p>
              <p>Você agora faz parte da comunidade Bureau Social e tem acesso ao portal exclusivo de associados.</p>
              <h3>Próximos Passos:</h3>
              <ul>
                <li>Acesse o portal em: <a href="${process.env.VITE_APP_URL || 'http://localhost:5173'}/portal">Portal do Associado</a></li>
                <li>Complete seu perfil</li>
                <li>Explore os documentos e recursos disponíveis</li>
                <li>Participe das assembleias e votações</li>
              </ul>
              <p>Estamos felizes em tê-lo(a) conosco nesta jornada de impacto social!</p>
            </div>
            <div class="footer">
              <p>Instituto Português de Negócios Sociais – Bureau Social</p>
              <p>Rua do Salvador, 20, 1.º A, 1100-383 Lisboa, Portugal</p>
              <p>+351 931 721 901 | info@bureausocial.pt</p>
            </div>
          </div>
        </body>
        </html>
      `
    });

    if (error) {
      console.error('Erro ao enviar email de boas-vindas:', error);
      return { success: false, error };
    }

    console.log('✅ Email de boas-vindas enviado para:', email);
    return { success: true, data };
  } catch (error) {
    console.error('Erro ao enviar email:', error);
    return { success: false, error: error.message };
  }
}

module.exports = {
  sendVerificationEmail,
  sendWelcomeEmail
};

