const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const crypto = require('crypto');
const db = require('../db/init.cjs');
const { sendVerificationEmail, sendWelcomeEmail } = require('../utils/email.cjs');
const { JWT_SECRET } = require('../middleware/auth.cjs');

const router = express.Router();

// Cadastro de novo associado
router.post('/register', async (req, res) => {
  try {
    const { name, email, password, phone, category } = req.body;

    // Validações
    if (!name || !email || !password) {
      return res.status(400).json({ error: 'Nome, email e senha são obrigatórios' });
    }

    if (password.length < 8) {
      return res.status(400).json({ error: 'A senha deve ter no mínimo 8 caracteres' });
    }

    // Verificar se email já existe
    const existingUser = db.prepare('SELECT * FROM users WHERE email = ?').get(email);
    if (existingUser) {
      return res.status(400).json({ error: 'Este email já está cadastrado' });
    }

    // Hash da senha
    const hashedPassword = await bcrypt.hash(password, 10);

    // Gerar token de verificação
    const verificationToken = crypto.randomBytes(32).toString('hex');

    // Inserir usuário
    const result = db.prepare(`
      INSERT INTO users (name, email, password, phone, category, verification_token)
      VALUES (?, ?, ?, ?, ?, ?)
    `).run(name, email, hashedPassword, phone || null, category || 'efetivo', verificationToken);

    // Enviar email de verificação
    await sendVerificationEmail(email, name, verificationToken);

    res.status(201).json({
      message: 'Cadastro realizado com sucesso! Verifique seu email para ativar sua conta.',
      userId: result.lastInsertRowid
    });
  } catch (error) {
    console.error('Erro no cadastro:', error);
    res.status(500).json({ error: 'Erro ao realizar cadastro' });
  }
});

// Verificar email
router.get('/verify-email/:token', async (req, res) => {
  try {
    const { token } = req.params;

    const user = db.prepare('SELECT * FROM users WHERE verification_token = ?').get(token);

    if (!user) {
      return res.status(400).json({ error: 'Token inválido ou expirado' });
    }

    // Ativar usuário
    db.prepare(`
      UPDATE users 
      SET status = 'active', email_verified = 1, verification_token = NULL, updated_at = CURRENT_TIMESTAMP
      WHERE id = ?
    `).run(user.id);

    // Enviar email de boas-vindas
    await sendWelcomeEmail(user.email, user.name);

    res.json({ message: 'Email verificado com sucesso! Sua conta está ativa.' });
  } catch (error) {
    console.error('Erro na verificação:', error);
    res.status(500).json({ error: 'Erro ao verificar email' });
  }
});

// Login
router.post('/login', async (req, res) => {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      return res.status(400).json({ error: 'Email e senha são obrigatórios' });
    }

    // Buscar usuário
    const user = db.prepare('SELECT * FROM users WHERE email = ?').get(email);

    if (!user) {
      return res.status(401).json({ error: 'Email ou senha incorretos' });
    }

    // Verificar senha
    const passwordMatch = await bcrypt.compare(password, user.password);

    if (!passwordMatch) {
      return res.status(401).json({ error: 'Email ou senha incorretos' });
    }

    // Verificar se email foi verificado
    if (!user.email_verified) {
      return res.status(403).json({ error: 'Por favor, verifique seu email antes de fazer login' });
    }

    // Verificar se conta está ativa
    if (user.status !== 'active') {
      return res.status(403).json({ error: 'Sua conta está pendente de aprovação' });
    }

    // Gerar JWT
    const token = jwt.sign(
      { userId: user.id, email: user.email, category: user.category },
      JWT_SECRET,
      { expiresIn: '7d' }
    );

    res.json({
      message: 'Login realizado com sucesso',
      token,
      user: {
        id: user.id,
        name: user.name,
        email: user.email,
        category: user.category,
        status: user.status
      }
    });
  } catch (error) {
    console.error('Erro no login:', error);
    res.status(500).json({ error: 'Erro ao realizar login' });
  }
});

// Obter dados do usuário logado
router.get('/me', async (req, res) => {
  try {
    const token = req.headers.authorization?.replace('Bearer ', '');
    
    if (!token) {
      return res.status(401).json({ error: 'Token não fornecido' });
    }

    const decoded = jwt.verify(token, JWT_SECRET);
    const user = db.prepare('SELECT id, name, email, phone, category, status, created_at FROM users WHERE id = ?').get(decoded.userId);

    if (!user) {
      return res.status(404).json({ error: 'Usuário não encontrado' });
    }

    res.json({ user });
  } catch (error) {
    console.error('Erro ao obter usuário:', error);
    res.status(401).json({ error: 'Token inválido' });
  }
});

module.exports = router;

