const jwt = require('jsonwebtoken');
const db = require('../db/init.cjs');

const JWT_SECRET = process.env.JWT_SECRET || 'bureau-social-secret-key-2025';

function authMiddleware(req, res, next) {
  try {
    const token = req.headers.authorization?.replace('Bearer ', '');
    
    if (!token) {
      return res.status(401).json({ error: 'Token não fornecido' });
    }

    const decoded = jwt.verify(token, JWT_SECRET);
    
    const user = db.prepare('SELECT id, name, email, category, status FROM users WHERE id = ?').get(decoded.userId);
    
    if (!user) {
      return res.status(401).json({ error: 'Usuário não encontrado' });
    }

    if (user.status !== 'active') {
      return res.status(403).json({ error: 'Conta não ativada' });
    }

    req.user = user;
    next();
  } catch (error) {
    console.error('Erro de autenticação:', error);
    return res.status(401).json({ error: 'Token inválido' });
  }
}

module.exports = { authMiddleware, JWT_SECRET };

