# Bureau Social - Pacote Completo de Arquivos

## Sobre o Projeto

O **Instituto Português de Negócios Sociais – Bureau Social** é uma associação sem fins lucrativos que promove projetos de impacto socioambiental através de governança participativa e parcerias estratégicas.

Este pacote contém todos os arquivos do projeto, incluindo código-fonte, documentos e análises.

---

## Estrutura do Pacote

```
bureau-social-download/
├── projeto/                    # Código-fonte do website
│   ├── src/                    # Componentes React e páginas
│   ├── public/                 # Arquivos estáticos
│   ├── drizzle/                # Esquemas de banco de dados
│   ├── package.json            # Dependências do projeto
│   └── ...
├── documentos/                 # PDFs principais
│   ├── MATERIAL_ARTESAOS_ARTISTAS_MORADIA.pdf
│   ├── PROJETO_IMOVEL_GRACA_ALFAMA_LISBOA.pdf
│   └── Sinergias_Quinta_Visconde_Salreu.pdf
├── analises/                   # Documentos de análise
│   ├── ANALISE_SITE_BUREAU_SOCIAL.md
│   └── ANALISE_IMOVEL_SANTA_CASA.md
├── imagens/                    # Imagens originais
└── README.md                   # Este arquivo
```

---

## Documentos Incluídos

### 1. Material para Artesãos e Artistas (PDF - 25 páginas)
Documento explicativo do programa "Moradia em Troca de Conhecimento" que oferece habitação a custo reduzido para artesãos, artistas e mestres de ofícios tradicionais em troca de 8 horas mensais de ensino.

### 2. Projeto Técnico do Imóvel (PDF - 80+ páginas)
Projeto técnico completo de restauro e reabilitação de edifício devoluto da Santa Casa da Misericórdia na zona da Graça/Alfama, Lisboa. Inclui:
- Orçamento detalhado: €1.1M (€450K primeira fase)
- Cronograma: 24-30 meses
- 8-10 unidades habitacionais
- 15-20 empregos criados
- Certificação ESG via GreenCheck

### 3. Sinergias Quinta do Visconde de Salreu (PDF)
Relatório de sinergias entre Bureau Social e GreenCheck para o projeto de regeneração socioambiental em Estarreja.

---

## Como Executar o Projeto

### Pré-requisitos
- Node.js 22+
- pnpm

### Instalação
```bash
cd projeto
pnpm install
pnpm dev
```

### Build para Produção
```bash
pnpm build
```

---

## Tecnologias Utilizadas

- **Frontend**: React 19, Vite 6, Tailwind CSS 4
- **UI Components**: shadcn/ui, Framer Motion
- **Internacionalização**: i18next (PT/EN)
- **Backend**: Node.js, Express 5, SQLite
- **Autenticação**: JWT + bcrypt
- **Email**: Resend.com

---

## Contato

- **Email**: diego@greencheck.pt
- **Telefone**: +351 931 721 901
- **Website**: https://bureau-q77ebc.manus.space/

---

## Licença

© 2026 Bureau Social - Instituto Português de Negócios Sociais. Todos os direitos reservados.
