# Análise Visual do Imóvel Devoluto - Santa Casa da Misericórdia

## Identificação do Imóvel

**Localização:** Lisboa (Graça/Alfama - a confirmar)  
**Proprietário:** Santa Casa da Misericórdia de Lisboa  
**Status:** Devoluto / Abandonado  
**Data da Análise:** 04 de Dezembro de 2025

---

## Observações Visuais das Fotografias

### Fachada Principal

**Estado Geral:** Degradação avançada

1. **Revestimento Exterior**
   - Reboco com perda significativa de aderência
   - Áreas extensas de destacamento
   - Humidade ascensional visível (manchas escuras na base)
   - Pintura completamente degradada

2. **Vãos (Portas e Janelas)**
   - Porta principal selada
   - Janelas com persianas metálicas fechadas
   - Caixilharia aparentemente em madeira (necessita verificação)
   - Alguns vidros partidos ou ausentes

3. **Varandas**
   - Pelo menos 2 varandas com guardas metálicas
   - Guardas apresentam corrosão
   - Lajes das varandas com sinais de degradação
   - Risco estrutural aparente

4. **Elementos Decorativos**
   - Características arquitetônicas típicas de Lisboa (século XIX/XX)
   - Elementos em cantaria possivelmente preserváveis

### Problemas Identificados

1. **Vandalismo**
   - Graffiti em várias áreas da fachada
   - Possível acesso não autorizado

2. **Humidade**
   - Humidade ascensional (base das paredes)
   - Possível infiltração por cobertura
   - Manchas de bolor visíveis

3. **Estrutura**
   - Fissuras aparentes
   - Risco de destacamento de elementos
   - Estado das lajes a verificar

4. **Instalações**
   - Cabos elétricos expostos e desorganizados
   - Instalações elétricas obsoletas

### Contexto Urbano

- Edifício inserido em zona histórica
- Edifícios adjacentes habitados e em melhor estado
- Rua estreita típica de bairros históricos lisboetas
- Iluminação pública presente

---

## Potencial do Imóvel

### Pontos Positivos

1. **Localização Premium**
   - Bairro histórico de Lisboa (Graça/Alfama)
   - Alta procura turística
   - Proximidade a pontos de interesse

2. **Valor Patrimonial**
   - Arquitetura típica lisboeta
   - Elementos recuperáveis
   - Interesse histórico

3. **Estrutura Aparente**
   - Paredes mestras aparentemente sólidas
   - Pé-direito adequado
   - Distribuição vertical interessante

### Desafios

1. **Investimento Necessário**
   - Restauro profundo necessário
   - Custos elevados de reabilitação
   - Necessidade de projeto especializado

2. **Regulamentação**
   - Zona protegida (possíveis restrições)
   - Necessidade de aprovações múltiplas
   - Obrigatoriedade de manter características

3. **Técnicos**
   - Necessidade de pedreiros especializados
   - Materiais tradicionais
   - Técnicas de restauro específicas

---

## Estimativa Preliminar

### Área Estimada
- **Frente:** ~5-6 metros
- **Pisos:** 3-4 pisos
- **Área Total Estimada:** 150-200 m²

### Tipologia Possível
- R/C: Comércio ou espaço social
- 1º e 2º Pisos: Habitação (T1 ou T2)
- Último Piso: Habitação com terraço (possível)

---

## Próximos Passos Necessários

1. ✅ Identificação exata do imóvel
2. ✅ Pesquisa de cadastro e propriedade
3. ✅ Levantamento topográfico
4. ✅ Inspeção estrutural detalhada
5. ✅ Projeto de arquitetura
6. ✅ Projeto de engenharia
7. ✅ Orçamentação detalhada

---

**Nota:** Esta análise é preliminar e baseada apenas em observação visual externa. É essencial realizar inspeção técnica completa antes de qualquer intervenção.
