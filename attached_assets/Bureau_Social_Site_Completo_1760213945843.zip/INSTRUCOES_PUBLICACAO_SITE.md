# INSTRUÇÕES PARA PUBLICAÇÃO DO SITE
## INSTITUTO PORTUGUÊS DE NEGÓCIOS SOCIAIS – BUREAU SOCIAL

---

## 📦 ARQUIVOS DISPONÍVEIS

Você recebeu dois arquivos ZIP:

1. **Bureau_Social_Site_Completo.zip** (6.5 MB)
   - Código-fonte completo do projeto
   - Para desenvolvimento e personalização
   - Requer Node.js e pnpm para executar

2. **Bureau_Social_Site_Build.zip** (13 MB)
   - Arquivos compilados prontos para publicação
   - Pasta `dist/` contém o site pronto
   - Basta fazer upload para qualquer servidor web

---

## 🚀 OPÇÃO 1: PUBLICAÇÃO RÁPIDA (RECOMENDADO)

### Usando o arquivo Build (Bureau_Social_Site_Build.zip)

**Passo 1:** Extrair o arquivo
```bash
unzip Bureau_Social_Site_Build.zip
```

**Passo 2:** Fazer upload da pasta `dist/` para o servidor

Você pode usar qualquer uma destas opções:

#### A) Hospedagem Gratuita - Netlify
1. Acesse https://www.netlify.com
2. Crie uma conta gratuita
3. Arraste a pasta `dist/` para o painel do Netlify
4. Pronto! Seu site estará online em segundos

#### B) Hospedagem Gratuita - Vercel
1. Acesse https://vercel.com
2. Crie uma conta gratuita
3. Clique em "Add New Project"
4. Faça upload da pasta `dist/`
5. Clique em "Deploy"

#### C) Servidor próprio (cPanel, FTP, etc.)
1. Acesse o painel de controle do seu servidor
2. Navegue até a pasta pública (geralmente `public_html/` ou `www/`)
3. Faça upload de todos os arquivos da pasta `dist/`
4. Pronto!

---

## 🛠️ OPÇÃO 2: DESENVOLVIMENTO E PERSONALIZAÇÃO

### Usando o código-fonte completo (Bureau_Social_Site_Completo.zip)

**Requisitos:**
- Node.js 18+ instalado
- pnpm instalado

**Passo 1:** Extrair e instalar dependências
```bash
unzip Bureau_Social_Site_Completo.zip
cd bureau-social-website
pnpm install
```

**Passo 2:** Executar em modo de desenvolvimento
```bash
pnpm run dev
```
O site estará disponível em http://localhost:5173

**Passo 3:** Fazer alterações
- Edite os arquivos em `src/`
- As alterações aparecerão automaticamente no navegador

**Passo 4:** Compilar para produção
```bash
pnpm run build
```
Os arquivos compilados estarão na pasta `dist/`

**Passo 5:** Publicar
Faça upload da pasta `dist/` para o servidor (ver Opção 1)

---

## 📁 ESTRUTURA DO PROJETO

```
bureau-social-website/
├── dist/                          # Site compilado (pronto para publicação)
│   ├── index.html
│   ├── assets/                    # CSS, JS e imagens
│   └── documentos/                # PDFs para download
├── src/                           # Código-fonte
│   ├── App.jsx                    # Componente principal
│   ├── App.css                    # Estilos personalizados
│   ├── assets/                    # Logos e imagens
│   └── components/                # Componentes UI
├── public/                        # Arquivos públicos
│   └── documentos/                # Documentos PDF
├── package.json                   # Dependências do projeto
└── vite.config.js                 # Configuração do Vite
```

---

## 🎨 PERSONALIZAÇÃO

### Alterar Cores
Edite o arquivo `src/App.css` e modifique as variáveis CSS:
```css
--primary: oklch(0.28 0.04 220);    /* Cor primária */
--secondary: oklch(0.58 0.02 220);  /* Cor secundária */
```

### Alterar Logo
Substitua o arquivo `src/assets/LogotipoVerde.png` pelo novo logo

### Alterar Conteúdo
Edite o arquivo `src/App.jsx` e modifique os textos e informações

### Adicionar Documentos
1. Coloque os PDFs na pasta `public/documentos/`
2. Edite `src/App.jsx` e adicione o documento na lista `documents`

---

## 📧 CONFIGURAÇÃO DO FORMULÁRIO DE CONTATO

O formulário está configurado para enviar emails para **diego@greencheck.pt** usando o serviço FormSubmit.

### Primeira Utilização
1. Ao enviar o primeiro formulário, você receberá um email de confirmação
2. Clique no link de confirmação para ativar o serviço
3. A partir daí, todos os formulários funcionarão automaticamente

### Alterar Email de Destino
Edite o arquivo `src/App.jsx` na linha 809:
```javascript
const response = await fetch('https://formsubmit.co/ajax/SEU_EMAIL@exemplo.com', {
```

---

## 🌐 DOMÍNIO PERSONALIZADO

### Netlify
1. No painel do Netlify, vá em "Domain Settings"
2. Clique em "Add custom domain"
3. Siga as instruções para configurar o DNS

### Vercel
1. No painel do Vercel, vá em "Settings" > "Domains"
2. Adicione seu domínio personalizado
3. Configure os registros DNS conforme indicado

### Servidor Próprio
- Aponte o domínio para o IP do servidor
- Configure o servidor web (Apache/Nginx) para servir a pasta `dist/`

---

## 📱 RECURSOS DO SITE

✅ **Design Responsivo:** Funciona perfeitamente em desktop, tablet e mobile
✅ **Formulário Inteligente:** Campos dinâmicos conforme tipo de contato
✅ **Central de Documentos:** 22 documentos organizados em 7 categorias
✅ **SEO Otimizado:** Meta tags e estrutura para melhor indexação
✅ **Performance:** Carregamento rápido e otimizado
✅ **Acessibilidade:** Navegação por teclado e contraste adequado

---

## 🆘 SUPORTE

### Problemas Comuns

**Erro ao instalar dependências:**
```bash
# Limpar cache e reinstalar
rm -rf node_modules pnpm-lock.yaml
pnpm install
```

**Site não carrega após publicação:**
- Verifique se todos os arquivos da pasta `dist/` foram enviados
- Verifique se o arquivo `index.html` está na raiz
- Limpe o cache do navegador (Ctrl+Shift+R)

**Formulário não envia emails:**
- Confirme o email de ativação do FormSubmit
- Verifique se o email está correto no código
- Teste em modo de navegação anônima

---

## 📞 CONTATO

Para dúvidas sobre o site ou personalização:
- **Email:** diego@greencheck.pt
- **Telefone:** +351 931 721 901

---

**Desenvolvido para o Instituto Português de Negócios Sociais – Bureau Social**
**Data:** Outubro 2025
**Tecnologias:** React + Vite + TailwindCSS

