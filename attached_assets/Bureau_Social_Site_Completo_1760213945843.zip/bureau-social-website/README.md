# Site Bureau Social

Site institucional do **Instituto Português de Negócios Sociais – Bureau Social**.

## 🚀 Tecnologias

- React 18
- Vite
- Tailwind CSS
- shadcn/ui
- Lucide Icons
- React Router

## 📁 Estrutura

```
bureau-social-website/
├── public/
│   └── documentos/          # Documentos para download
├── src/
│   ├── assets/              # Imagens e logotipos
│   ├── components/          # Componentes React
│   ├── App.jsx              # Componente principal
│   └── App.css              # Estilos personalizados
└── index.html               # HTML principal
```

## 🛠️ Desenvolvimento

### Instalar dependências
```bash
pnpm install
```

### Executar em modo desenvolvimento
```bash
pnpm run dev
```

### Build para produção
```bash
pnpm run build
```

### Preview do build
```bash
pnpm run preview
```

## 📄 Páginas

- **Início** - Apresentação e áreas de atuação
- **Quem Somos** - Missão, visão, valores e princípios ESG
- **Áreas de Atuação** - Detalhamento das áreas estratégicas
- **Associe-se** - Informações sobre categorias de associados
- **Parcerias** - Tipos de parceiros e colaborações
- **Documentos** - Central de documentos institucionais
- **Notícias** - Atualizações e eventos
- **Contato** - Formulário e informações de contato

## 🎨 Personalização

As cores do Bureau Social estão definidas em `src/App.css`:

- **Verde Primário**: Cor principal da marca
- **Verde Escuro**: Contraste e profissionalismo
- **Verde Claro**: Destaques e hover states

## 📚 Documentação

Para mais informações sobre uso e manutenção, consulte:
- `guia_uso_manutencao.md` - Guia completo de uso
- `analise_e_recomendacoes.md` - Análise e estratégias

## 📝 Licença

© 2025 Instituto Português de Negócios Sociais - Bureau Social

