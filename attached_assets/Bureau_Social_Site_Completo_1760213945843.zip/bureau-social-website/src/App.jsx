import { useState } from 'react'
import { BrowserRouter as Router, Routes, Route, Link, useLocation } from 'react-router-dom'
import { Button } from '@/components/ui/button.jsx'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { 
  Menu, X, Home, Users, Briefcase, UserPlus, Handshake, 
  FileText, Newspaper, Mail, ChevronRight, Download,
  Building2, Lightbulb, Leaf, Recycle, GraduationCap,
  Facebook, Twitter, Linkedin, Instagram, MapPin, Phone, Send
} from 'lucide-react'
import logoVerde from './assets/LogotipoVerde.png'
import './App.css'

// Header Component
function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false)
  const location = useLocation()

  const menuItems = [
    { name: 'Início', path: '/', icon: Home },
    { name: 'Quem Somos', path: '/quem-somos', icon: Users },
    { name: 'Áreas de Atuação', path: '/areas-atuacao', icon: Briefcase },
    { name: 'Associe-se', path: '/associe-se', icon: UserPlus },
    { name: 'Parcerias', path: '/parcerias', icon: Handshake },
    { name: 'Documentos', path: '/documentos', icon: FileText },
    { name: 'Notícias', path: '/noticias', icon: Newspaper },
    { name: 'Contato', path: '/contato', icon: Mail },
  ]

  return (
    <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <nav className="container-custom flex h-16 items-center justify-between">
        <Link to="/" className="flex items-center space-x-2">
          <img src={logoVerde} alt="Bureau Social" className="h-12" />
        </Link>

        {/* Desktop Menu */}
        <div className="hidden md:flex items-center space-x-1">
          {menuItems.map((item) => (
            <Link
              key={item.path}
              to={item.path}
              className={`px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                location.pathname === item.path
                  ? 'bg-primary text-primary-foreground'
                  : 'text-foreground/80 hover:bg-accent hover:text-accent-foreground'
              }`}
            >
              {item.name}
            </Link>
          ))}
        </div>

        {/* Mobile Menu Button */}
        <button
          className="md:hidden p-2"
          onClick={() => setIsMenuOpen(!isMenuOpen)}
          aria-label="Toggle menu"
        >
          {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
        </button>
      </nav>

      {/* Mobile Menu */}
      {isMenuOpen && (
        <div className="md:hidden border-t">
          <div className="container-custom py-4 space-y-2">
            {menuItems.map((item) => {
              const Icon = item.icon
              return (
                <Link
                  key={item.path}
                  to={item.path}
                  onClick={() => setIsMenuOpen(false)}
                  className={`flex items-center space-x-2 px-4 py-3 rounded-md transition-colors ${
                    location.pathname === item.path
                      ? 'bg-primary text-primary-foreground'
                      : 'text-foreground/80 hover:bg-accent hover:text-accent-foreground'
                  }`}
                >
                  <Icon size={20} />
                  <span>{item.name}</span>
                </Link>
              )
            })}
          </div>
        </div>
      )}
    </header>
  )
}

// Footer Component
function Footer() {
  return (
    <footer className="bg-secondary text-secondary-foreground">
      <div className="container-custom py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* About */}
          <div>
            <h3 className="font-bold text-lg mb-4">Bureau Social</h3>
            <p className="text-sm opacity-90">
              Instituto Português de Negócios Sociais promovendo impacto positivo e negócios rentáveis.
            </p>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="font-bold text-lg mb-4">Links Rápidos</h3>
            <ul className="space-y-2 text-sm">
              <li><Link to="/quem-somos" className="opacity-90 hover:opacity-100 transition-opacity">Quem Somos</Link></li>
              <li><Link to="/areas-atuacao" className="opacity-90 hover:opacity-100 transition-opacity">Áreas de Atuação</Link></li>
              <li><Link to="/associe-se" className="opacity-90 hover:opacity-100 transition-opacity">Associe-se</Link></li>
              <li><Link to="/documentos" className="opacity-90 hover:opacity-100 transition-opacity">Documentos</Link></li>
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h3 className="font-bold text-lg mb-4">Contato</h3>
            <ul className="space-y-2 text-sm">
              <li className="flex items-start space-x-2">
                <MapPin size={16} className="mt-1 flex-shrink-0" />
                <span className="opacity-90">Rua do Salvador, 20, 1.º A<br />1100-383 Lisboa, Portugal</span>
              </li>
              <li className="flex items-center space-x-2">
                <Phone size={16} className="flex-shrink-0" />
                <a href="tel:+351931721901" className="opacity-90 hover:opacity-100 transition-opacity">+351 931 721 901</a>
              </li>
              <li className="flex items-center space-x-2">
                <Mail size={16} className="flex-shrink-0" />
                <span className="opacity-90">info@bureausocial.pt</span>
              </li>
            </ul>
          </div>

          {/* Social Media */}
          <div>
            <h3 className="font-bold text-lg mb-4">Redes Sociais</h3>
            <div className="flex space-x-4">
              <a href="#" className="opacity-90 hover:opacity-100 transition-opacity" aria-label="Facebook">
                <Facebook size={24} />
              </a>
              <a href="#" className="opacity-90 hover:opacity-100 transition-opacity" aria-label="Twitter">
                <Twitter size={24} />
              </a>
              <a href="#" className="opacity-90 hover:opacity-100 transition-opacity" aria-label="LinkedIn">
                <Linkedin size={24} />
              </a>
              <a href="#" className="opacity-90 hover:opacity-100 transition-opacity" aria-label="Instagram">
                <Instagram size={24} />
              </a>
            </div>
          </div>
        </div>

        <div className="mt-8 pt-8 border-t border-secondary-foreground/20 text-center text-sm opacity-75">
          <p>&copy; {new Date().getFullYear()} Instituto Português de Negócios Sociais - Bureau Social. Todos os direitos reservados.</p>
        </div>
      </div>
    </footer>
  )
}

// Home Page
function HomePage() {
  const areas = [
    {
      icon: Building2,
      title: 'Habitação Social',
      description: 'Reabilitação de imóveis devolutos para famílias em risco, promovendo habitação digna e acessível.'
    },
    {
      icon: Lightbulb,
      title: 'Empreendedorismo Social',
      description: 'Apoio a negócios sociais inovadores através de incubação, formação e mentoria especializada.'
    },
    {
      icon: Leaf,
      title: 'Sustentabilidade ESG',
      description: 'Práticas sustentáveis e formação em competências verdes alinhadas com princípios ESG.'
    },
    {
      icon: Recycle,
      title: 'Economia Circular',
      description: 'Inclusão produtiva e emprego verde através de projetos de economia circular e sustentabilidade.'
    },
    {
      icon: GraduationCap,
      title: 'Educação Cidadã',
      description: 'Literacia cívica e participação democrática através de programas educativos não formais.'
    }
  ]

  return (
    <div>
      {/* Hero Section */}
      <section className="hero-gradient text-white">
        <div className="container-custom section-padding">
          <div className="max-w-3xl mx-auto text-center">
            <h1 className="text-4xl md:text-6xl font-bold mb-6 animate-fade-in">
              Impacto Positivo e Negócios Rentáveis
            </h1>
            <p className="text-xl md:text-2xl mb-8 opacity-95 animate-fade-in-up">
              Promovendo soluções inovadoras de economia social para a realização dos direitos sociais em Portugal
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center animate-fade-in-up">
              <Button asChild size="lg" className="bg-white text-primary hover:bg-white/90">
                <Link to="/associe-se">
                  Associe-se <ChevronRight className="ml-2" size={20} />
                </Link>
              </Button>
              <Button asChild size="lg" variant="outline" className="bg-transparent border-white text-white hover:bg-white/10">
                <Link to="/quem-somos">
                  Conheça Nosso Trabalho
                </Link>
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* About Section */}
      <section className="section-padding bg-muted/30">
        <div className="container-custom">
          <div className="max-w-4xl mx-auto text-center">
            <h2 className="text-3xl md:text-4xl font-bold mb-6">Sobre o Instituto</h2>
            <p className="text-lg text-muted-foreground leading-relaxed">
              O Instituto Português de Negócios Sociais – Bureau Social é uma IPSS dedicada à promoção de soluções 
              inovadoras de economia social que contribuem para a realização dos direitos sociais em Portugal. 
              Atuamos nas áreas de habitação social, empreendedorismo social, sustentabilidade ambiental, 
              economia circular e educação para a cidadania, sempre alinhados com os Objetivos de Desenvolvimento 
              Sustentável da ONU e os princípios ESG.
            </p>
          </div>
        </div>
      </section>

      {/* Areas Section */}
      <section className="section-padding">
        <div className="container-custom">
          <h2 className="text-3xl md:text-4xl font-bold text-center mb-12">Áreas de Atuação</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {areas.map((area, index) => {
              const Icon = area.icon
              return (
                <Card key={index} className="card-hover">
                  <CardHeader>
                    <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center mb-4">
                      <Icon className="text-primary" size={24} />
                    </div>
                    <CardTitle>{area.title}</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <CardDescription className="text-base">{area.description}</CardDescription>
                  </CardContent>
                </Card>
              )
            })}
          </div>
          <div className="text-center mt-8">
            <Button asChild size="lg" variant="outline">
              <Link to="/areas-atuacao">
                Ver Todas as Áreas <ChevronRight className="ml-2" size={20} />
              </Link>
            </Button>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="section-padding bg-primary text-primary-foreground">
        <div className="container-custom text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-6">Junte-se a Nós</h2>
          <p className="text-xl mb-8 max-w-2xl mx-auto opacity-95">
            Faça parte de uma comunidade comprometida com a transformação social em Portugal. 
            Como associado, você contribui diretamente para a construção de uma sociedade mais justa e sustentável.
          </p>
          <Button asChild size="lg" className="bg-white text-primary hover:bg-white/90">
            <Link to="/associe-se">
              Torne-se Associado <ChevronRight className="ml-2" size={20} />
            </Link>
          </Button>
        </div>
      </section>
    </div>
  )
}

// Quem Somos Page
function QuemSomosPage() {
  return (
    <div className="section-padding">
      <div className="container-custom">
        <h1 className="text-4xl md:text-5xl font-bold mb-8">Quem Somos</h1>
        
        <div className="max-w-4xl space-y-8">
          <section>
            <h2 className="text-2xl font-bold mb-4 text-primary">Missão</h2>
            <p className="text-lg text-muted-foreground leading-relaxed">
              Promover soluções inovadoras de economia social que contribuam para a realização dos direitos sociais 
              em Portugal, dando expressão organizada ao dever moral de justiça e solidariedade, contribuindo para 
              a efetivação dos direitos sociais dos cidadãos.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-bold mb-4 text-primary">Visão</h2>
            <p className="text-lg text-muted-foreground leading-relaxed">
              Tornar-se referência nacional na construção de soluções sociais sustentáveis e inclusivas, inspirando 
              outras organizações e mobilizando parcerias público-privadas para transformar comunidades e promover 
              o desenvolvimento integral das pessoas.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-bold mb-4 text-primary">Valores</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {[
                { title: 'Solidariedade', desc: 'Compromisso com a justiça social e apoio mútuo' },
                { title: 'Inovação', desc: 'Busca constante por soluções criativas e eficazes' },
                { title: 'Transparência', desc: 'Prestação de contas clara e acessível' },
                { title: 'Sustentabilidade', desc: 'Práticas ambientalmente responsáveis' },
                { title: 'Inclusão', desc: 'Promoção da diversidade e participação de todos' },
                { title: 'Autonomia', desc: 'Respeito pela autodeterminação das pessoas' }
              ].map((value, index) => (
                <Card key={index}>
                  <CardHeader>
                    <CardTitle className="text-lg">{value.title}</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-muted-foreground">{value.desc}</p>
                  </CardContent>
                </Card>
              ))}
            </div>
          </section>

          <section>
            <h2 className="text-2xl font-bold mb-4 text-primary">Princípios ESG</h2>
            <p className="text-lg text-muted-foreground leading-relaxed mb-4">
              O Instituto integra os princípios ESG (Environmental, Social and Governance) em todas as suas atividades:
            </p>
            <ul className="space-y-3 text-muted-foreground">
              <li className="flex items-start space-x-2">
                <Leaf className="text-primary mt-1 flex-shrink-0" size={20} />
                <span><strong>Ambiental:</strong> Projetos de economia circular, eficiência energética e sustentabilidade</span>
              </li>
              <li className="flex items-start space-x-2">
                <Users className="text-primary mt-1 flex-shrink-0" size={20} />
                <span><strong>Social:</strong> Inclusão de grupos vulneráveis, habitação digna e educação para cidadania</span>
              </li>
              <li className="flex items-start space-x-2">
                <Briefcase className="text-primary mt-1 flex-shrink-0" size={20} />
                <span><strong>Governança:</strong> Transparência, prestação de contas e gestão democrática</span>
              </li>
            </ul>
          </section>
        </div>
      </div>
    </div>
  )
}

// Areas de Atuacao Page
function AreasAtuacaoPage() {
  const areas = [
    {
      icon: Building2,
      title: 'Habitação Social e Reutilização de Imóveis Devolutos',
      description: 'Atuamos na identificação e reabilitação de habitações degradadas ou desocupadas para realojar famílias em risco, em coordenação com entidades como o IHRU e as câmaras municipais. Apoiamos a criação de protocolos com autarquias para recuperação de imóveis municipais e privados, conjugando o estatuto de IPSS com programas de arrendamento acessível e reabilitação urbana.'
    },
    {
      icon: Lightbulb,
      title: 'Inovação e Empreendedorismo Social',
      description: 'Promovemos a criação e escalonamento de negócios sociais inovadores que resolvem problemas comunitários. Apoiamos incubadoras sociais, formações (bootcamps de empreendedorismo social) e eventos de co-criação. Oferecemos apoio técnico (mentoria, capacitação em gestão de impacto) a empreendedores sociais e colaboração com entidades parceiras.'
    },
    {
      icon: Leaf,
      title: 'Sustentabilidade Ambiental e Princípios ESG',
      description: 'Integramos práticas sustentáveis e ESG em todas as atividades. Desenvolvemos projetos que reduzem pegada ambiental (reutilização de recursos, eficiência energética em reabilitações). Oferecemos formação em competências verdes, promovemos ações de educação ambiental comunitária e incentivamos projetos de energias renováveis e economia verde.'
    },
    {
      icon: Recycle,
      title: 'Economia Circular, Inclusão Produtiva e Emprego Verde',
      description: 'Fomentamos a inclusão de grupos vulneráveis no mercado de trabalho através de cadeias produtivas sustentáveis. Apoiamos projetos de reciclagem, compostagem comunitária, mobilidade sustentável e cadeias de valor local. Articulamos programas de reconversão profissional para maximizar empregabilidade em setores ambientais e energias limpas.'
    },
    {
      icon: GraduationCap,
      title: 'Educação para a Cidadania e Envolvimento Comunitário',
      description: 'Fortalecemos a literacia cívica e a participação democrática. Promovemos ações educativas não formais (oficinas, campanhas, voluntariado) para reforçar valores democráticos, direitos humanos e responsabilidade social. Trabalhamos em parceria com escolas, associações culturais e forças vivas locais para eventos cívicos e fóruns participativos.'
    }
  ]

  return (
    <div className="section-padding">
      <div className="container-custom">
        <h1 className="text-4xl md:text-5xl font-bold mb-8">Áreas de Atuação</h1>
        <p className="text-xl text-muted-foreground mb-12 max-w-3xl">
          O Bureau Social desenvolve programas de impacto social em diversas áreas estratégicas, 
          sempre alinhados com os Objetivos de Desenvolvimento Sustentável da ONU e os princípios ESG.
        </p>

        <div className="space-y-8">
          {areas.map((area, index) => {
            const Icon = area.icon
            return (
              <Card key={index} className="card-hover">
                <CardHeader>
                  <div className="flex items-start space-x-4">
                    <div className="w-16 h-16 rounded-lg bg-primary/10 flex items-center justify-center flex-shrink-0">
                      <Icon className="text-primary" size={32} />
                    </div>
                    <div>
                      <CardTitle className="text-2xl mb-2">{area.title}</CardTitle>
                      <CardDescription className="text-base leading-relaxed">{area.description}</CardDescription>
                    </div>
                  </div>
                </CardHeader>
              </Card>
            )
          })}
        </div>
      </div>
    </div>
  )
}

// Associe-se Page
function AssociesePage() {
  const categories = [
    {
      title: 'Fundadores',
      description: 'Pessoas singulares que participaram na assembleia de constituição e se comprometem a colaborar na manutenção do Instituto.',
      quota: 'Quota associativa'
    },
    {
      title: 'Efetivos',
      description: 'Associados que, após anos de participação como contribuintes e sem infrações disciplinares, sejam convidados pela Direção.',
      quota: 'Quota associativa'
    },
    {
      title: 'Contribuintes',
      description: 'Pessoas singulares que solicitem adesão após a constituição e que paguem quotas associativas.',
      quota: 'Quota associativa'
    },
    {
      title: 'Voluntários',
      description: 'Pessoas singulares que integrem as equipas de voluntariado do Instituto.',
      quota: 'Isento de quotas'
    },
    {
      title: 'Profissionais',
      description: 'Prestadores ou especialistas de diferentes áreas que colaborem em projetos do Instituto.',
      quota: 'Isento de quotas'
    },
    {
      title: 'Beneméritos',
      description: 'Pessoas singulares que tenham prestado serviços relevantes ou feito doações significativas.',
      quota: 'Isento de quotas'
    },
    {
      title: 'Patrocinadores',
      description: 'Pessoas coletivas (empresas ou instituições) que apoiem financeiramente ou patrocinem regularmente as atividades.',
      quota: 'Variável'
    },
    {
      title: 'Institucionais',
      description: 'Pessoas coletivas do primeiro, segundo ou terceiro setor que participem em projetos do Instituto.',
      quota: 'Variável'
    }
  ]

  return (
    <div className="section-padding">
      <div className="container-custom">
        <h1 className="text-4xl md:text-5xl font-bold mb-8">Associe-se</h1>
        <p className="text-xl text-muted-foreground mb-12 max-w-3xl">
          Faça parte de uma comunidade comprometida com a transformação social em Portugal. Como associado do Bureau Social, 
          você contribui diretamente para a construção de uma sociedade mais justa, inclusiva e sustentável.
        </p>

        <section className="mb-12">
          <h2 className="text-3xl font-bold mb-6">Categorias de Associados</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {categories.map((category, index) => (
              <Card key={index} className="card-hover">
                <CardHeader>
                  <CardTitle className="text-xl">{category.title}</CardTitle>
                  <CardDescription className="text-base leading-relaxed">{category.description}</CardDescription>
                </CardHeader>
                <CardContent>
                  <p className="text-sm font-medium text-primary">{category.quota}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </section>

        <section className="mb-12">
          <h2 className="text-3xl font-bold mb-6">Benefícios de Ser Associado</h2>
          <Card>
            <CardContent className="pt-6">
              <ul className="space-y-3">
                {[
                  'Participação nas atividades e projetos do Instituto',
                  'Direito a voto na Assembleia Geral (associados válidos)',
                  'Acesso a formações e eventos exclusivos',
                  'Networking com profissionais e organizações do setor social',
                  'Contribuição direta para o impacto social em Portugal',
                  'Certificado de associado',
                  'Newsletter mensal com atualizações'
                ].map((benefit, index) => (
                  <li key={index} className="flex items-start space-x-2">
                    <ChevronRight className="text-primary mt-1 flex-shrink-0" size={20} />
                    <span>{benefit}</span>
                  </li>
                ))}
              </ul>
            </CardContent>
          </Card>
        </section>

        <section>
          <Card className="bg-primary text-primary-foreground">
            <CardHeader>
              <CardTitle className="text-2xl">Como Se Associar</CardTitle>
              <CardDescription className="text-primary-foreground/90 text-base">
                Para se tornar associado, entre em contato conosco através do formulário de contato ou envie um email 
                manifestando seu interesse. Nossa equipe entrará em contato para orientá-lo sobre o processo de adesão.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Button asChild size="lg" className="bg-white text-primary hover:bg-white/90">
                <Link to="/contato">
                  Entre em Contato <ChevronRight className="ml-2" size={20} />
                </Link>
              </Button>
            </CardContent>
          </Card>
        </section>
      </div>
    </div>
  )
}

// Parcerias Page
function ParceriasPage() {
  const partnerTypes = [
    {
      title: 'Autarquias Locais',
      description: 'Estabelecemos protocolos com municípios para utilizar património público e executar programas sociais. Trabalhamos em coordenação com Câmaras Municipais, especialmente em Lisboa e Porto, para projetos de habitação social e reabilitação urbana.',
      examples: ['Câmara Municipal de Lisboa', 'Câmara Municipal do Porto', 'Juntas de Freguesia']
    },
    {
      title: 'Governo Central',
      description: 'Cooperação com ministérios e institutos governamentais para desenvolvimento de programas sociais e acesso a financiamento público.',
      examples: ['IHRU - Instituto da Habitação e Reabilitação Urbana', 'Ministério do Trabalho e Solidariedade', 'Ministério do Ambiente', 'Segurança Social']
    },
    {
      title: 'Organismos Europeus',
      description: 'Articulação com fundos e iniciativas europeias para financiamento de projetos de inovação social e desenvolvimento comunitário.',
      examples: ['Portugal 2030', 'Plano de Recuperação e Resiliência (PRR)', 'Fundo Social Europeu', 'EEA Grants']
    },
    {
      title: 'Parceiros Estratégicos',
      description: 'Colaboração com organizações do terceiro setor, empresas sociais e instituições académicas para desenvolvimento de projetos conjuntos.',
      examples: ['Portugal Inovação Social', 'IES - Instituto de Empreendedorismo Social', 'Universidades', 'Fundações']
    }
  ]

  return (
    <div className="section-padding">
      <div className="container-custom">
        <h1 className="text-4xl md:text-5xl font-bold mb-8">Parcerias</h1>
        <p className="text-xl text-muted-foreground mb-12 max-w-3xl">
          O Bureau Social acredita no poder das parcerias para amplificar o impacto social. Trabalhamos em colaboração 
          com entidades públicas, privadas e do terceiro setor para desenvolver soluções inovadoras e sustentáveis.
        </p>

        <div className="space-y-8 mb-12">
          {partnerTypes.map((type, index) => (
            <Card key={index} className="card-hover">
              <CardHeader>
                <CardTitle className="text-2xl mb-2">{type.title}</CardTitle>
                <CardDescription className="text-base leading-relaxed">{type.description}</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex flex-wrap gap-2">
                  {type.examples.map((example, idx) => (
                    <span key={idx} className="px-3 py-1 bg-primary/10 text-primary rounded-full text-sm">
                      {example}
                    </span>
                  ))}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        <Card className="bg-accent">
          <CardHeader>
            <CardTitle className="text-2xl">Seja Nosso Parceiro</CardTitle>
            <CardDescription className="text-base">
              Interessado em estabelecer uma parceria com o Bureau Social? Entre em contato conosco para 
              explorar oportunidades de colaboração que gerem impacto positivo nas comunidades.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Button asChild size="lg">
              <Link to="/contato">
                Entre em Contato <ChevronRight className="ml-2" size={20} />
              </Link>
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

// Documentos Page - Will be implemented in next phase
function DocumentosPage() {
      const documents = [
    {
      category: 'Estatutos e Regulamentos',
      files: [
        { name: 'Estatuto do Instituto Português de Negócios Sociais', file: 'EstatutodoInstitutoPortuguêsdeNegóciosSociais.docx' },
        { name: 'Estatuto do Instituto (PDF)', file: 'EstatutodoInstitutoPortuguêsdeNegóciosSociais–BureauSocial.pdf' },
        { name: 'Ata de Constituição', file: 'Ata_Constituicao_Bureau_Social.pdf' },
        { name: 'Regulamento Interno', file: 'Regulamento_Interno_Bureau_Social.pdf' },
        { name: 'Regulamento de Quotas e Contribuições', file: 'Regulamento_Quotas_Contribuicoes_Bureau_Social.pdf' },
        { name: 'Regulamento Eleitoral', file: 'Regulamento_Eleitoral_Bureau_Social.pdf' },
        { name: 'Regulamento de Utilização de Instalações', file: 'Regulamento_Utilizacao_Instalacoes_Bureau_Social.pdf' }
      ]
    },
    {
      category: 'Governança e Ética',
      files: [
        { name: 'Código de Conduta e Ética', file: 'Codigo_Conduta_Etica_Bureau_Social.pdf' },
        { name: 'Política de Proteção de Dados (RGPD)', file: 'Politica_Protecao_Dados_RGPD_Bureau_Social.pdf' },
        { name: 'Política de Conflito de Interesses', file: 'Politica_Conflito_Interesses_Bureau_Social.pdf' }
      ]
    },
    {
      category: 'Escopo Institucional',
      files: [
        { name: 'Escopo Institucional - Bureau Social', file: 'InstitutoPortuguêsdeNegóciosSociais–BureauSocial_EscopoInstitucional.pdf' }
      ]
    },
    {
      category: 'Planeamento e Estratégia',
      files: [
        { name: 'Plano de Atividades 2026', file: 'Plano_Atividades_2026_Bureau_Social.pdf' },
        { name: 'Orçamento 2026', file: 'Orcamento_2026_Bureau_Social.pdf' },
        { name: 'Plano de Captação de Recursos 2026', file: 'Plano_Captacao_Recursos_2026_Bureau_Social.pdf' },
        { name: 'Plano Estratégico Trienal 2026-2028', file: 'Plano_Estrategico_Trienal_2026_2028_Bureau_Social.pdf' },
        { name: 'Plano de Comunicação e Marketing', file: 'Plano_Comunicacao_Marketing_Bureau_Social.pdf' },
        { name: 'Apresentação Institucional', file: 'Apresentacao_Institucional_Bureau_Social.pdf' }
      ]
    },
    {
      category: 'Documentos Operacionais',
      files: [
        { name: 'Política de Compras e Contratações', file: 'Politica_Compras_Contratacoes_Bureau_Social.pdf' },
        { name: 'Política de Recursos Humanos', file: 'Politica_Recursos_Humanos_Bureau_Social.pdf' },
        { name: 'Manual de Procedimentos Administrativos e Financeiros', file: 'Manual_Procedimentos_Administrativos_Financeiros_Bureau_Social.pdf' },
        { name: 'Plano de Voluntariado', file: 'Plano_Voluntariado_Bureau_Social.pdf' }
      ]
    },
    {
      category: 'Documentos para Associados',
      files: [
        { name: 'Ficha de Candidatura a Associado', file: 'Ficha_Candidatura_Associado_Bureau_Social.pdf' },
        { name: 'Manual do Associado', file: 'Manual_Associado_Bureau_Social.pdf' },
        { name: 'Termo de Adesão', file: 'Termo_Adesao_Associado_Bureau_Social.pdf' }
      ]
    },
    {
      category: 'Prestação de Contas',
      files: [
        { name: 'Relatório de Atividades e Contas (Modelo)', file: 'Relatorio_Atividades_Contas_Modelo_Bureau_Social.pdf' }
      ]
    }
  ]

  return (
    <div className="section-padding">
      <div className="container-custom">
        <h1 className="text-4xl md:text-5xl font-bold mb-8">Documentos</h1>
        <p className="text-xl text-muted-foreground mb-12 max-w-3xl">
          Acesse os documentos institucionais do Bureau Social. Mantemos transparência total sobre nossa 
          estrutura organizacional, estatutos e relatórios de atividades.
        </p>

        <div className="space-y-8">
          {documents.map((section, index) => (
            <section key={index}>
              <h2 className="text-2xl font-bold mb-4 text-primary">{section.category}</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {section.files.map((doc, idx) => (
                  <Card key={idx} className="card-hover">
                    <CardHeader>
                      <div className="flex items-start justify-between">
                        <div className="flex items-start space-x-3 flex-1">
                          <FileText className="text-primary mt-1 flex-shrink-0" size={24} />
                          <div>
                            <CardTitle className="text-lg">{doc.name}</CardTitle>
                            <CardDescription className="text-sm mt-1">
                              {doc.file.endsWith('.pdf') ? 'Documento PDF' : 'Documento Word'}
                            </CardDescription>
                          </div>
                        </div>
                        <Button asChild size="sm" variant="ghost">
                          <a href={`/documentos/${doc.file}`} download>
                            <Download size={20} />
                          </a>
                        </Button>
                      </div>
                    </CardHeader>
                  </Card>
                ))}
              </div>
            </section>
          ))}
        </div>
      </div>
    </div>
  )
}

// Noticias Page
function NoticiasPage() {
  return (
    <div className="section-padding">
      <div className="container-custom">
        <h1 className="text-4xl md:text-5xl font-bold mb-8">Notícias</h1>
        <p className="text-xl text-muted-foreground mb-12 max-w-3xl">
          Acompanhe as últimas novidades, eventos e conquistas do Bureau Social.
        </p>

        <Card className="text-center py-12">
          <CardContent>
            <Newspaper className="mx-auto mb-4 text-muted-foreground" size={48} />
            <CardTitle className="text-2xl mb-2">Em Breve</CardTitle>
            <CardDescription className="text-base">
              Esta seção será atualizada em breve com as últimas notícias e eventos do Instituto.
            </CardDescription>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

// Contato Page
function ContatoPage() {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    subject: '',
    organization: '',
    projectDescription: '',
    message: ''
  })
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [submitStatus, setSubmitStatus] = useState(null)

  const contactTypes = [
    { value: 'associado', label: 'Quero ser Associado', fields: ['name', 'email', 'phone', 'organization'] },
    { value: 'parceria', label: 'Proposta de Parceria', fields: ['name', 'email', 'phone', 'organization', 'projectDescription'] },
    { value: 'voluntario', label: 'Quero ser Voluntário', fields: ['name', 'email', 'phone'] },
    { value: 'projeto', label: 'Submeter Projeto', fields: ['name', 'email', 'phone', 'organization', 'projectDescription'] },
    { value: 'duvida', label: 'Dúvida ou Informação', fields: ['name', 'email'] },
    { value: 'outro', label: 'Outro Assunto', fields: ['name', 'email', 'phone'] }
  ]

  const handleSubjectChange = (e) => {
    setFormData({ ...formData, subject: e.target.value })
  }

  const handleInputChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value })
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    setIsSubmitting(true)
    setSubmitStatus(null)

    try {
      // Prepare email content
      const selectedType = contactTypes.find(t => t.value === formData.subject)
      const emailContent = `
Nova mensagem do site Bureau Social

Tipo de Contato: ${selectedType?.label || 'Não especificado'}

Nome: ${formData.name}
Email: ${formData.email}
${formData.phone ? `Telefone: ${formData.phone}` : ''}
${formData.organization ? `Organização: ${formData.organization}` : ''}
${formData.projectDescription ? `Descrição do Projeto:\n${formData.projectDescription}` : ''}
${formData.message ? `Mensagem:\n${formData.message}` : ''}
      `.trim()

      // Send email using fetch to a serverless function or API
      const response = await fetch('https://formsubmit.co/ajax/diego@greencheck.pt', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json'
        },
        body: JSON.stringify({
          name: formData.name,
          email: formData.email,
          subject: `[Bureau Social] ${selectedType?.label || 'Contato'}`,
          message: emailContent
        })
      })

      if (response.ok) {
        setSubmitStatus('success')
        setFormData({
          name: '',
          email: '',
          phone: '',
          subject: '',
          organization: '',
          projectDescription: '',
          message: ''
        })
      } else {
        setSubmitStatus('error')
      }
    } catch (error) {
      console.error('Error sending email:', error)
      setSubmitStatus('error')
    } finally {
      setIsSubmitting(false)
    }
  }

  const selectedType = contactTypes.find(t => t.value === formData.subject)
  const requiredFields = selectedType?.fields || []

  return (
    <div className="section-padding">
      <div className="container-custom">
        <h1 className="text-4xl md:text-5xl font-bold mb-8">Contato</h1>
        <p className="text-xl text-muted-foreground mb-12 max-w-3xl">
          Entre em contato conosco. Estamos à disposição para esclarecer dúvidas, receber sugestões 
          e discutir oportunidades de colaboração.
        </p>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Contact Info */}
          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <MapPin className="text-primary" />
                  <span>Morada</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  Rua do Salvador, 20, 1.º A<br />
                  1100-383 Lisboa, Portugal
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Phone className="text-primary" />
                  <span>Telefone</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  <a href="tel:+351931721901" className="hover:text-primary transition-colors">
                    +351 931 721 901
                  </a>
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Mail className="text-primary" />
                  <span>Email</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  <a href="mailto:info@bureausocial.pt" className="hover:text-primary transition-colors">
                    info@bureausocial.pt
                  </a>
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Redes Sociais</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex space-x-4">
                  <a href="#" className="text-muted-foreground hover:text-primary transition-colors">
                    <Facebook size={24} />
                  </a>
                  <a href="#" className="text-muted-foreground hover:text-primary transition-colors">
                    <Twitter size={24} />
                  </a>
                  <a href="#" className="text-muted-foreground hover:text-primary transition-colors">
                    <Linkedin size={24} />
                  </a>
                  <a href="#" className="text-muted-foreground hover:text-primary transition-colors">
                    <Instagram size={24} />
                  </a>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Contact Form */}
          <Card>
            <CardHeader>
              <CardTitle>Envie uma Mensagem</CardTitle>
              <CardDescription>Selecione o tipo de contato e preencha o formulário abaixo.</CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmit} className="space-y-4">
                {/* Subject Selection */}
                <div>
                  <label htmlFor="subject" className="block text-sm font-medium mb-2">
                    Tipo de Contato <span className="text-destructive">*</span>
                  </label>
                  <select
                    id="subject"
                    name="subject"
                    value={formData.subject}
                    onChange={handleSubjectChange}
                    className="w-full px-3 py-2 border border-input rounded-md focus:outline-none focus:ring-2 focus:ring-ring"
                    required
                  >
                    <option value="">Selecione uma opção...</option>
                    {contactTypes.map(type => (
                      <option key={type.value} value={type.value}>{type.label}</option>
                    ))}
                  </select>
                </div>

                {/* Dynamic Fields */}
                {formData.subject && (
                  <>
                    {requiredFields.includes('name') && (
                      <div>
                        <label htmlFor="name" className="block text-sm font-medium mb-2">
                          Nome Completo <span className="text-destructive">*</span>
                        </label>
                        <input
                          type="text"
                          id="name"
                          name="name"
                          value={formData.name}
                          onChange={handleInputChange}
                          className="w-full px-3 py-2 border border-input rounded-md focus:outline-none focus:ring-2 focus:ring-ring"
                          placeholder="Seu nome completo"
                          required
                        />
                      </div>
                    )}

                    {requiredFields.includes('email') && (
                      <div>
                        <label htmlFor="email" className="block text-sm font-medium mb-2">
                          Email <span className="text-destructive">*</span>
                        </label>
                        <input
                          type="email"
                          id="email"
                          name="email"
                          value={formData.email}
                          onChange={handleInputChange}
                          className="w-full px-3 py-2 border border-input rounded-md focus:outline-none focus:ring-2 focus:ring-ring"
                          placeholder="seu@email.com"
                          required
                        />
                      </div>
                    )}

                    {requiredFields.includes('phone') && (
                      <div>
                        <label htmlFor="phone" className="block text-sm font-medium mb-2">
                          Telefone {formData.subject === 'duvida' ? '' : <span className="text-destructive">*</span>}
                        </label>
                        <input
                          type="tel"
                          id="phone"
                          name="phone"
                          value={formData.phone}
                          onChange={handleInputChange}
                          className="w-full px-3 py-2 border border-input rounded-md focus:outline-none focus:ring-2 focus:ring-ring"
                          placeholder="+351 XXX XXX XXX"
                          required={formData.subject !== 'duvida'}
                        />
                      </div>
                    )}

                    {requiredFields.includes('organization') && (
                      <div>
                        <label htmlFor="organization" className="block text-sm font-medium mb-2">
                          Organização/Empresa
                        </label>
                        <input
                          type="text"
                          id="organization"
                          name="organization"
                          value={formData.organization}
                          onChange={handleInputChange}
                          className="w-full px-3 py-2 border border-input rounded-md focus:outline-none focus:ring-2 focus:ring-ring"
                          placeholder="Nome da organização"
                        />
                      </div>
                    )}

                    {requiredFields.includes('projectDescription') && (
                      <div>
                        <label htmlFor="projectDescription" className="block text-sm font-medium mb-2">
                          Descrição do Projeto/Proposta
                        </label>
                        <textarea
                          id="projectDescription"
                          name="projectDescription"
                          value={formData.projectDescription}
                          onChange={handleInputChange}
                          rows="4"
                          className="w-full px-3 py-2 border border-input rounded-md focus:outline-none focus:ring-2 focus:ring-ring"
                          placeholder="Descreva brevemente o projeto ou proposta..."
                        ></textarea>
                      </div>
                    )}

                    <div>
                      <label htmlFor="message" className="block text-sm font-medium mb-2">
                        Mensagem Adicional
                      </label>
                      <textarea
                        id="message"
                        name="message"
                        value={formData.message}
                        onChange={handleInputChange}
                        rows="4"
                        className="w-full px-3 py-2 border border-input rounded-md focus:outline-none focus:ring-2 focus:ring-ring"
                        placeholder="Informações adicionais (opcional)..."
                      ></textarea>
                    </div>

                    {submitStatus === 'success' && (
                      <div className="p-4 bg-green-50 border border-green-200 rounded-md text-green-800">
                        Mensagem enviada com sucesso! Entraremos em contato em breve.
                      </div>
                    )}

                    {submitStatus === 'error' && (
                      <div className="p-4 bg-red-50 border border-red-200 rounded-md text-red-800">
                        Erro ao enviar mensagem. Por favor, tente novamente ou entre em contato por email.
                      </div>
                    )}

                    <Button type="submit" size="lg" className="w-full" disabled={isSubmitting}>
                      {isSubmitting ? 'Enviando...' : 'Enviar Mensagem'} <Send className="ml-2" size={20} />
                    </Button>
                  </>
                )}
              </form>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}

// Main App Component
function App() {
  return (
    <Router>
      <div className="min-h-screen flex flex-col">
        <Header />
        <main className="flex-1">
          <Routes>
            <Route path="/" element={<HomePage />} />
            <Route path="/quem-somos" element={<QuemSomosPage />} />
            <Route path="/areas-atuacao" element={<AreasAtuacaoPage />} />
            <Route path="/associe-se" element={<AssociesePage />} />
            <Route path="/parcerias" element={<ParceriasPage />} />
            <Route path="/documentos" element={<DocumentosPage />} />
            <Route path="/noticias" element={<NoticiasPage />} />
            <Route path="/contato" element={<ContatoPage />} />
          </Routes>
        </main>
        <Footer />
      </div>
    </Router>
  )
}

export default App

